<?php 
require_once 'header.php';
?>

<div>
		<!--Parte de cima-->
		<div class="container" style="padding: 100px; ">
			<div class="row">
				<div class="col-sm-1"></div>
				<div class="col-sm-4">
					<a href="cadastro-lote.php"><button class="btn btn-primary btn-sm" style="font-size:24px; min-width: 250px"><i style="font-size:35px"></i> <p>Lote Recebido</p> </button></a>
				</div>
				<div class="col-sm-2"></div>
				<div class="col-sm-4">
					<a href="cadastro-colheita.php"><button class="btn btn-primary btn-sm" style="font-size:24px; min-width: 250px"><i style="font-size:35px"></i> <p>Lote Colhido</p> </button></a>
				</div>
			</div>
		</div>
</div>

<?php
require_once 'footer.php';

?>