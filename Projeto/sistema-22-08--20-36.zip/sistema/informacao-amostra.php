<?php 

require_once 'header.php';
require 'crud.php';

$idamostra = $_GET['idamostra'];
$amostra = new Crud();
$tbnumerosementes = new Crud();
$tbteoragua = new Crud();
$tbgerminacao = new Crud();
//$tbresultado = new Crud();
$tbtotalplantulas = new Crud();
$tbplantulasanormais = new Crud();
$tbsementesfirmes = new Crud();
$tbsementesmortas = new Crud();
$tbsementeschocas = new Crud();
$velo_germinacao = new Crud();


$amostra->select("SELECT idlote_sementes, data_chegada, categoria, nome_vulgar, nome_cientifico, familia, condicao_armazenamento, data_implantacao FROM amostra, lote, especie WHERE idamostra=$idamostra and loteFK=idlote_sementes and especieFK=id_especie ");

foreach ($amostra->result() as $amostra ){
	$idlote = $amostra['idlote_sementes'];
	$dtchegada = $amostra['data_chegada'];
	$categoria = $amostra['categoria'];
	$nomevulgar= $amostra['nome_vulgar'];
	$nomecientifico = $amostra['nome_cientifico'];
	$familia = $amostra['familia'];
	$armazenamento = $amostra['condicao_armazenamento'];
	$dtimplantacao = $amostra['data_implantacao'];
}

$tbnumerosementes->select('SELECT * FROM teste_num_sementes WHERE amostraFK ='.$idamostra);

$tbteoragua->select('SELECT * FROM teste_teor_agua WHERE amostraFK ='.$idamostra);

$tbgerminacao->select('SELECT * FROM teste_germinacao WHERE amostraFK ='.$idamostra);


//-----------------------DADOS FINAIS DA TABELA ------------------------
$velo_germinacao->select('SELECT count(*) FROM teste_germinacao where amostraFK='.$idamostra);
foreach ($velo_germinacao->result() as $velocidade ){
	$qtd_dias = $velocidade['count(*)'];
}
if ($qtd_dias > 0) {
	$tbtotalplantulas->select('SELECT * FROM total_plantulas4 WHERE amostraFK ='.$idamostra);
	foreach ($tbtotalplantulas->result() as $totalplantulas ){
		$totalplantulasr1 = $totalplantulas['r1'];
		$totalplantulasr2 = $totalplantulas['r2'];
		$totalplantulasr3 = $totalplantulas['r3'];
		$totalplantulasr4 = $totalplantulas['r4'];
		$totalplantulas = $totalplantulas['total'];
	}

	$tbplantulasanormais->select('SELECT * FROM plantulas_anormais4 WHERE amostraFK ='.$idamostra);
	foreach ($tbplantulasanormais->result() as $plantulasanormais ){
		$plantulasanormaisr1 = $plantulasanormais['r1'];
		$plantulasanormaisr2 = $plantulasanormais['r2'];
		$plantulasanormaisr3 = $plantulasanormais['r3'];
		$plantulasanormaisr4 = $plantulasanormais['r4'];
		$totalplantulasanormais = $plantulasanormais['total'];
	}

	$porcent_plantulasanormaisr1 = (($plantulasanormaisr1*100)/$totalplantulasr1);
	$porcent_plantulasanormaisr2 = (($plantulasanormaisr2*100)/$totalplantulasr2);
	$porcent_plantulasanormaisr3 = (($plantulasanormaisr3*100)/$totalplantulasr3);
	$porcent_plantulasanormaisr4 = (($plantulasanormaisr4*100)/$totalplantulasr4);
	$porcent_totalplantulasanormais = (($totalplantulasanormais*100)/$totalplantulas);

	$tbsementesfirmes->select('SELECT * FROM sementes_firmes4 WHERE amostraFK ='.$idamostra);
	foreach ($tbsementesfirmes->result() as $sementesfirmes ){
		$sementesfirmesr1 = $sementesfirmes['r1'];
		$sementesfirmesr2 = $sementesfirmes['r2'];
		$sementesfirmesr3 = $sementesfirmes['r3'];
		$sementesfirmesr4 = $sementesfirmes['r4'];
		$totalsementesfirmes = $sementesfirmes['total'];
	}

	$porcent_sementesfirmesr1 = (($sementesfirmesr1*100)/$totalplantulasr1);
	$porcent_sementesfirmesr2 = (($sementesfirmesr2*100)/$totalplantulasr2);
	$porcent_sementesfirmesr3 = (($sementesfirmesr3*100)/$totalplantulasr3);
	$porcent_sementesfirmesr4 = (($sementesfirmesr4*100)/$totalplantulasr4);
	$porcent_totalsementesfirmes = (($totalsementesfirmes*100)/$totalplantulas);

	$tbsementesmortas->select('SELECT * FROM sementes_mortas4 WHERE amostraFK ='.$idamostra);
	foreach ($tbsementesmortas->result() as $sementesmortas ){
		$sementesmortasr1 = $sementesmortas['r1'];
		$sementesmortasr2 = $sementesmortas['r2'];
		$sementesmortasr3 = $sementesmortas['r3'];
		$sementesmortasr4 = $sementesmortas['r4'];
		$totalsementesmortas = $sementesmortas['total'];
	}

	$porcent_sementesmortasr1 = (($sementesmortasr1*100)/$totalplantulasr1);
	$porcent_sementesmortasr2 = (($sementesmortasr2*100)/$totalplantulasr2);
	$porcent_sementesmortasr3 = (($sementesmortasr3*100)/$totalplantulasr3);
	$porcent_sementesmortasr4 = (($sementesmortasr4*100)/$totalplantulasr4);
	$porcent_totalsementesmortas = (($totalsementesmortas*100)/$totalplantulas);

	$tbsementeschocas->select('SELECT * FROM sementes_chocas4 WHERE amostraFK ='.$idamostra);
	foreach ($tbsementeschocas->result() as $sementeschocas ){
		$sementeschocasr1 = $sementeschocas['r1'];
		$sementeschocasr2 = $sementeschocas['r2'];
		$sementeschocasr3 = $sementeschocas['r3'];
		$sementeschocasr4 = $sementeschocas['r4'];
		$totalsementeschocas = $sementeschocas['total'];
	}

	$porcent_sementeschocasr1 = (($sementeschocasr1*100)/$totalplantulasr1);
	$porcent_sementeschocasr2 = (($sementeschocasr2*100)/$totalplantulasr2);
	$porcent_sementeschocasr3 = (($sementeschocasr3*100)/$totalplantulasr3);
	$porcent_sementeschocasr4 = (($sementeschocasr4*100)/$totalplantulasr4);
	$porcent_totalsementeschocas = (($totalsementeschocas*100)/$totalplantulas);
//----------------------------- FIM -------------------------------
} else{
	$totalplantulasr1='';
	$totalplantulasr2='';
	$totalplantulasr3='';
	$totalplantulasr4='';
	$totalplantulas='';

	$plantulasanormaisr1='';
	$plantulasanormaisr2='';
	$plantulasanormaisr3='';
	$plantulasanormaisr4='';
	$totalplantulasanormais='';
	$porcent_plantulasanormaisr1='';
	$porcent_plantulasanormaisr2='';
	$porcent_plantulasanormaisr3='';
	$porcent_plantulasanormaisr4='';
	$porcent_totalplantulasanormais='';

	$sementesfirmesr1='';
	$sementesfirmesr2='';
	$sementesfirmesr3='';
	$sementesfirmesr4='';
	$totalsementesfirmes='';
	$porcent_sementesfirmesr1='';
	$porcent_sementesfirmesr2='';
	$porcent_sementesfirmesr3='';
	$porcent_sementesfirmesr4='';
	$porcent_totalsementesfirmes='';

	$sementesmortasr1='';
	$sementesmortasr2='';
	$sementesmortasr3='';
	$sementesmortasr4='';
	$totalsementesmortas='';
	$porcent_sementesmortasr1='';
	$porcent_sementesmortasr2='';
	$porcent_sementesmortasr3='';
	$porcent_sementesmortasr4='';
	$porcent_totalsementesmortas='';

	$sementeschocasr1='';
	$sementeschocasr2='';
	$sementeschocasr3='';
	$sementeschocasr4='';
	$totalsementeschocas='';
	$porcent_sementeschocasr1='';
	$porcent_sementeschocasr2='';
	$porcent_sementeschocasr3='';
	$porcent_sementeschocasr4='';
	$porcent_totalsementeschocas='';
}

?>

<div class="container">
	<h2>Amostra</h2>

	<ul class="nav nav-tabs">
		<li class="active"><a data-toggle="tab" href="#home">Dados da Amostra</a></li>
		<li><a data-toggle="tab" href="#menu1">Número de Sementes</a></li>
		<li><a data-toggle="tab" href="#menu2">Análise Teor de Água</a></li>
		<li><a data-toggle="tab" href="#menu3">Análise da Germinação</a></li>
		<li><a data-toggle="tab" href="#menu4">Resultado</a></li>
	</ul>

	<div class="tab-content">
		<div id="home" class="tab-pane fade in active">
			<h3>Dados da Amostra</h3>
			<div class="row">
				<div class="col-sm-2 ">
					<div class="form-group">
						<label for="loteOrigem">Código:</label> 
						<input type="text" class="form-control" name="codamostra" id="codamostra" value="<?php echo $idamostra?>" disabled="true">
					</div>
				</div>
				<div class="col-sm-2 ">
					<div class="form-group">
						<label for="loteOrigem">Lote de Origem:</label> 
						<input type="text" class="form-control" name="loteOrigem" id="loteOrigem" value="<?php echo $idlote?>" disabled="true">
					</div>
				</div>
				<div class="form-group col-sm-4 ">
					<label for="categoria">Categoria:</label> <!-- fornecido ou colhido -->
					<input type="text" class="form-control" name="categoria" id="categoria" value="<?php echo $categoria?>" disabled="">
				</div>	
				<div class="form-group col-sm-4 ">
					<label for="dataEntradaLoteOrigem">Data de entrada:</label> 
					<input type="text" class="form-control" name="dataEntradaLoteOrigem" id="dataEntradaLoteOrigem" value="<?php echo $dtchegada?>" disabled="true">
				</div>

			</div>

			<div class="row">
				<div class="form-group col-sm-4">
					<label  for="especie">Especie:</label>
					<input type="text"  class="form-control"  name="especie" id="especie"  value="<?php echo $nomevulgar?>" disabled="true">
				</div>
				<div class="form-group col-sm-4">
					<label for="condicaoArmazenamento">Condição de Armazenamento:</label>	
					<input type="text"  class="form-control"  name="condicaoArmazenamento"value="<?php echo $armazenamento?>" id="condicaoArmazenamento"  disabled="true">
				</div>
				<div class="form-group col-sm-4">
					<label  for="dataImplatacao">Data Implantação:</label>
					<input type="date"  class="form-control"  name="dataImplatacao" id="dataImplatacao" value="<?php echo $dtimplantacao?>"  disabled="true">
				</div>
			</div>	

			<h3>Análises</h3>
			<hr>	
			<h4>Teor de Água</h4>
			<div class="container-fluid">
				<table  class="table table-hover">
					<thead>
						<tr>
							<th scope="col">N° do Cadinho</th>
							<th scope="col">Peso do Cadinho</th>
							<th scope="col">Peso Úmido</th>
							<th scope="col">Peso Seco</th>
							<th scope="col">Úmidade (%)</th>
							<th scope="col">Úmidade Média (%)</th>
							<th scope="col">Opções</th>
						</tr>
					</thead>
					<tbody>
						<?php 
						if ($tbteoragua->numRows() > 0) {
							foreach ($tbteoragua->result() as $tbteoragua ){ ?>
								<tr>
									<td ><?php echo $tbteoragua['num_cadinho']; ?></td>
									<td ><?php echo $tbteoragua['peso_cadinho']; ?></td>
									<td ><?php echo $tbteoragua['peso_umido']; ?></td>
									<td ><?php echo $tbteoragua['peso_seco']; ?></td>
									<td ><?php echo $tbteoragua['umidade']; ?></td>
									<td ><?php echo $tbteoragua['umidade_media']; ?></td>
									<td>
										<button type="button" id="<?php echo $tbteoragua['idteste_teor_agua'];?>" class="btn btn-info">Ver</button> 
										<button type="button" id="<?php echo $tbteoragua['idteste_teor_agua'];?>" class="btn btn-danger">Excluir</button>
									</td>
								</tr>										
							<?php }
						}
						?> 
					</tbody>
				</table>
			</div>

			<hr>
			<h4>Num. Sementes</h4>
			<div class="container-fluid">
				<table  class="table table-hover">
					<thead>
						<tr>
							<th scope="col">N° de Sementes</th>
							<th scope="col">Peso da Amostra</th>
							<th scope="col">N° Sementes (KH)</th>
							<th scope="col">Opções<th>
							</tr>
						</thead>
						<tbody>
							<?php 
							if ($tbnumerosementes->numRows() > 0) {
								foreach ($tbnumerosementes->result() as $tbnumerosemente ){ ?>
									<tr>
										<td><?php echo $tbnumerosemente['qtd_num_sementes']; ?></td>
										<td><?php echo $tbnumerosemente['peso_amostra']; ?></td>
										<td><?php echo $tbnumerosemente['kh_num_sementes']; ?></td>
										<td>
											<button type="button" id="<?php echo $tbnumerosemente['idteste_num_sementes'];?>" class="btn btn-info">Ver</button> 
											<button type="button" id="<?php echo $tbnumerosemente['idteste_num_sementes'];?>" class="btn btn-danger">Excluir</button>
										</td>
									</tr>
								<?php }
							}
							?> 
						</tbody>
					</table>
				</div>

				<hr>
				<h4>Teste Germinação</h4>
				<div class="container-fluid">
					<table  class="table table-hover">
						<thead>
							<tr>
								<th scope="col">N° dia da semeadura</th>
								<th scope="col">Data</th>
								<th scope="col">R1</th>
								<th scope="col">R2</th>
								<th scope="col">R3</th>
								<th scope="col">R4</th>
								<th scope="col">Total</th>
								<th scope="col">Opções</th>
							</tr>
						</thead>
						<tfoot>
							<tr>
								<td>Total Plantulas </td>
								<td><?php echo '' ?></td>
								<td><?php echo $totalplantulasr1 ?></td>
								<td><?php echo $totalplantulasr2 ?></td>
								<td><?php echo $totalplantulasr3 ?></td>
								<td><?php echo $totalplantulasr4 ?></td>
								<td><?php echo $totalplantulas ?></td>
								<td><?php echo '' ?></td>
								<td><?php echo '' ?></td>
							</tr>
							<tr>
								<td>Plantulas Anormais</td>
								<td><?php echo '' ?></td>
								<td><?php echo $plantulasanormaisr1 ?></td>
								<td><?php echo $plantulasanormaisr2 ?></td>
								<td><?php echo $plantulasanormaisr3 ?></td>
								<td><?php echo $plantulasanormaisr4 ?></td>
								<td><?php echo $totalplantulasanormais ?></td>
								<td><?php echo '' ?></td>
								<td><?php echo ''?></td>
							</tr>
							<tr>
								<td>Sementes Firmes</td>
								<td><?php echo ''?></td>
								<td><?php echo $sementesfirmesr1 ?></td>
								<td><?php echo $sementesfirmesr2 ?></td>
								<td><?php echo $sementesfirmesr3 ?></td>
								<td><?php echo $sementesfirmesr4 ?></td>
								<td><?php echo $totalsementesfirmes ?></td>
								<td><?php echo ''?></td>								
								<td><?php echo ''?></td>
							</tr>
							<tr>
								<td>Sementes Mortas</td>
								<td><?php echo ''?></td>
								<td><?php echo $sementesmortasr1 ?></td>
								<td><?php echo $sementesmortasr2 ?></td>
								<td><?php echo $sementesmortasr3 ?></td>
								<td><?php echo $sementesmortasr4 ?></td>
								<td><?php echo $totalsementesmortas ?></td>
								<td><?php echo ''?></td>
								<td><?php echo ''?></td>
							</tr>
							<tr>
								<td>Sementes Chocas</td>
								<td><?php echo ''?></td>
								<td><?php echo $sementeschocasr1 ?></td>
								<td><?php echo $sementeschocasr2 ?></td>
								<td><?php echo $sementeschocasr3 ?></td>
								<td><?php echo $sementeschocasr4 ?></td>
								<td><?php echo $totalsementeschocas ?></td>
								<td><?php echo ''?></td>
								<td><?php echo ''?></td>
							</tr>
						</tfoot>
						<tbody>
							<?php 
							if ($tbgerminacao->numRows() > 0) {
								foreach ($tbgerminacao->result() as $tbgerminacao ){ ?>
									<tr>
										<td><?php echo $tbgerminacao['num_dias_semeadura']; ?></td>
										<td><?php echo $tbgerminacao['data']; ?></td>
										<td><?php echo $tbgerminacao['repeticao1']; ?></td>
										<td><?php echo $tbgerminacao['repeticao2']; ?></td>
										<td><?php echo $tbgerminacao['repeticao3']; ?></td>
										<td><?php echo $tbgerminacao['repeticao4']; ?></td>
										<td><?php echo $tbgerminacao['total_repeticao']; ?></td>
										<td>
											<button type="button" id="<?php echo $tbgerminacao['idteste_germinacao'];?>" class="btn btn-info">Ver</button> 
											<button type="button" id="<?php echo $tbgerminacao['idteste_germinacao'];?>" class="btn btn-danger">Excluir</button>
										</td>
									</tr>
								<?php }
							}
							?> 
						</tbody>
					</table>

				</div>
				<hr>
				<h4>Resultado</h4>
				<div class="container-fluid">
					<table  class="table table-hover">
						<thead>
							<tr>
								<th scope="col">% Germinação</th>
								<th scope="col">R1</th>
								<th scope="col">R2</th>
								<th scope="col">R3</th>
								<th scope="col">R4</th>
								<th scope="col">Total</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>Velocidade de Germinação</td>
								<td><?php echo $totalplantulasr1?></td>
								<td><?php echo $totalplantulasr2?></td>
								<td><?php echo $totalplantulasr3?></td>
								<td><?php echo $totalplantulasr4?></td>
								<td><?php echo $totalplantulas?></td>
							</tr>
							<tr>
								<td>% Plantulas Anormais</td>
								<td><?php echo $porcent_plantulasanormaisr1?></td>
								<td><?php echo $porcent_plantulasanormaisr2?></td>
								<td><?php echo $porcent_plantulasanormaisr3?></td>
								<td><?php echo $porcent_plantulasanormaisr4?></td>
								<td><?php echo $porcent_totalplantulasanormais?></td>
							</tr>
							<tr>
								<td>% Sementes Firmes</td>
								<td><?php echo $porcent_sementesfirmesr1?></td>
								<td><?php echo $porcent_sementesfirmesr2?></td>
								<td><?php echo $porcent_sementesfirmesr3?></td>
								<td><?php echo $porcent_sementesfirmesr4?></td>
								<td><?php echo $porcent_totalsementesfirmes?></td>
							</tr>
							<tr>
								<td>% Sementes Mortas</td>
								<td><?php echo $porcent_sementesmortasr1?></td>
								<td><?php echo $porcent_sementesmortasr2?></td>
								<td><?php echo $porcent_sementesmortasr3?></td>
								<td><?php echo $porcent_sementesmortasr4?></td>
								<td><?php echo $porcent_totalsementesmortas?></td>
							</tr>
							<tr>
								<td>% Sementes Chocas</td>
								<td><?php echo $porcent_sementeschocasr1?></td>
								<td><?php echo $porcent_sementeschocasr2?></td>
								<td><?php echo $porcent_sementeschocasr3?></td>
								<td><?php echo $porcent_sementeschocasr4?></td>
								<td><?php echo $porcent_totalsementeschocas?></td>
							</tr>
						</tbody>
					</table>

				</div>
				<div class="row">
					<div class="form-group col-sm-7">						
						<a href="lista-amostra.php"><button type="submit" class="btn btn-primary"><span class="fa fa-mail-reply"></span> Voltar</button></a>

						<a href="cadastro-relatorio.php?idamostra=<?php echo $idamostra ?>"><button type="button" class="btn btn-success">Finalizar Análise</button></a>
						
					</div>
				</div>
			</div>
			<!-- ------------------------- Cadstro Numero de Sementes ------------------------------- -->
			<div id="menu1" class="tab-pane fade">
				<h3>Número de Sementes</h3>

				<form  name="formCardastroNumSementes" id="formCardastroNumSementes" method="POST" action="crud-amostra.php">
					<div class="row">
						<div class="col-sm-2 ">
							<div class="form-group">
								<label for="loteOrigem">Código:</label> 
								<input type="text" class="form-control" name="codamostra" id="codamostra" value="<?php echo $idamostra?>" readonly="">
							</div>
						</div>
						<div class="col-sm-2 ">
							<div class="form-group">
								<label for="loteOrigem">Lote de Origem:</label> 
								<input type="text" class="form-control" name="loteOrigem" id="loteOrigem" value="<?php echo $idlote?>" disabled="" >
							</div>
						</div>
						<div class="form-group col-sm-2 ">
							<label  for="especie">Especie:</label>
							<input type="text"  class="form-control"  name="especie" id="especie"  value="<?php echo $nomevulgar?>" disabled="">
						</div>	
						<div class="form-group col-sm-2 ">
							<label for="datanumsementes">Data Análise:</label> 
							<input type="date" class="form-control" name="datanumsementes" id="datanumsementes" required="">
						</div>
						<div class="form-group col-sm-4 ">
							<label for="analistaTesteNumSementes"> Analista: </label>
							<input type="text" class="form-control" name="analistaTesteNumSementes" id="analistaTesteNumSementes" maxlength="30" minlength="4" placeholder="Ex.: João da Silva" required="">
						</div>

					</div>
					<div class="row">
						<div class="col-sm-4 ">
							<div class="form-group">
								<label for="numSementes"> N° de Sementes: </label>
								<input type="number" class="form-control" name="numSementes" id="numSementes" min="0"  placeholder="Ex.: 500" required="">
							</div>
						</div>
						<div class="col-sm-4 ">
							<div class="form-group">
								<label for="pesoAmostra"> Peso da Amostra: </label>
								<input type="number" step="0.01" class="form-control" name="pesoAmostra" id="pesoAmostra" min="0"  placeholder="Ex.: 10" required="">
							</div>
						</div>
						<div class="form-group col-sm-4 ">
							<label for="numSementesKh"> N° Sementes (KH): </label>
							<input type="number" step="0.01" class="form-control" name="numSementesKh" id="numSementesKh"  min="0"  placeholder="Ex.: 10" required="">
						</div>
					</div>	
					<div class="row">
						<div class="form-group col-sm-12">
							<label for="obsTesteUmidade">Observação</label>
							<textarea  class="form-control" rows="5" name="obsTesteUmidade" id="obsTesteUmidade"></textarea>
						</div>
					</div>	
					<div class="row">
						<div class="form-group col-sm-12">
							<button class="btn btn-success btn-md" name="acao" value="createNumSementes"><span class="fa fa-plus-square-o"></span> Salvar </button>
						</div>
					</div>
				</form>
			</div>
			<!------------------------- Cadastro Teor de Agua -------------------------------->
			<div id="menu2" class="tab-pane fade">
				<h3>Análise Teor de Água</h3>
				<form name="formTesteTeorAgua" id="formTesteTeorAgua" method="POST" action="crud-amostra.php">
					<div class="row">
						<div class="col-sm-2 ">
							<div class="form-group">
								<label for="loteOrigem">Código:</label> 
								<input type="text" class="form-control" name="codamostra" id="codamostra" value="<?php echo $idamostra?>" readonly="">
							</div>
						</div>
						<div class="col-sm-2 ">
							<div class="form-group">
								<label for="loteOrigem">Lote de Origem:</label> 
								<input type="text" class="form-control" name="loteOrigem" id="loteOrigem" value="<?php echo $idlote?>" disabled="" >
							</div>
						</div>
						<div class="form-group col-sm-2 ">
							<label  for="especie">Especie:</label>
							<input type="text"  class="form-control"  name="especie" id="especie"  value="<?php echo $nomevulgar?>" disabled="">
						</div>
						<div class="form-group col-sm-2">
							<label for="dataTesteTeorAgua">Data Análise:</label> 
							<input type="date" class="form-control" name="dataTesteTeorAgua" id="dataTesteTeorAgua" required="">
						</div>
						<div class="form-group col-sm-4">
							<label for="analistaTesteTeorAgua">Analista:</label>
							<input type="text" class="form-control" name="analistaTesteTeorAgua" id="analistaTesteTeorAgua"    maxlength="30" minlength="4" placeholder="Ex.: João da Silva" required="">  
						</div>	
					</div>

					<div class="row">
						<div class="form-group col-sm-4">
							<label for="numCadinho">N° Cadinho:</label>
							<input type="number" class="form-control" name="numCadinho" id="numCadinho"   min="0" placeholder="Ex.: 1" required="">
						</div>

						<div class="form-group col-sm-4">
							<label for="pesoCadinho">Peso do Cadinho:</label>
							<input type="number" step="0.01" class="form-control" name="pesoCadinho" id="pesoCadinho" min="0" placeholder="Ex.: 1,25" required=""> 
						</div>

						<div class="form-group col-sm-4">
							<label for="pesoUmido">Peso Úmido:</label> 
							<input type="number" step="0.01" class="form-control" name="pesoUmido" id="pesoUmido" min="0" placeholder="Ex.: 3,45" required="">
						</div>
					</div>

					<div class="row">
						<div class="form-group col-sm-4">
							<label for="pesoSeco">Peso Seco:</label>      
							<input type="number" step="0.01" class="form-control" name="pesoSeco" id="pesoSeco" min="0" placeholder="Ex.: 1" required="">
						</div>

						<div class="form-group col-sm-4">
							<label for="umidade">Umidade (%):</label>
							<input type="number" step="0.01" class="form-control" name="umidade" id="umidade" min="0"  placeholder="Ex.: 30" required="">
						</div>

						<div class="form-group col-sm-4">
							<label for="umidadeMedia">Umidade Média (%):</label>
							<input type="number" step="0.01" class="form-control" name="umidadeMedia" id="umidadeMedia" min="1" placeholder="Ex.: 30" required="">
						</div>
					</div>

					<div class="row">  
						<div class="form-group col-sm-12">
							<label for="obsTesteUmidade">Observação</label>
							<textarea  class="form-control" rows="5" name="obsTesteUmidade"  maxlength="255" minlength="1"  id="obsTesteUmidade"></textarea>
						</div>
					</div>

					<div class="row">          
						<div class="form-group col-sm-12">
							<button class="btn btn-success btn-md" name="acao" value="createTesteTeorAgua"><span class="fa fa-plus-square-o"></span> Salvar </button>
						</div>
					</div>
				</form>
			</div>
			<!--------------------------------------- TESTE GERMINACAO -------------------------------------->	
			<div id="menu3" class="tab-pane fade">
				<h3>Análise da Germinação</h3>
				<form name="formCardastroTesteGerminacao" id="formCardastroTesteGerminacao" method="POST" action="crud-amostra.php">
					<div class="row">
						<div class="col-sm-2 ">
							<div class="form-group">
								<label for="loteOrigem">Código:</label> 
								<input type="text" class="form-control" name="codamostra" id="codamostra" value="<?php echo $idamostra?>" readonly="">
							</div>
						</div>
						<div class="col-sm-2 ">
							<div class="form-group">
								<label for="loteOrigem">Lote de Origem:</label> 
								<input type="text" class="form-control" name="loteOrigem" id="loteOrigem" value="<?php echo $idlote?>" disabled="" >
							</div>
						</div>
						<div class="form-group col-sm-2 ">
							<label  for="especie">Especie:</label>
							<input type="text"  class="form-control"  name="especie" id="especie"  value="<?php echo $nomevulgar?>" disabled="">
						</div>
						
						<div class="form-group col-sm-2">
							<label for="dataSemeadura">Data Semeadura:</label> 
							<input type="date" class="form-control" name="dataSemeadura" id="dataSemeadura" required="">
						</div>

						<div class="form-group col-sm-4">
							<label for="analistaTesteGerminacao">Analista:</label>
							<input type="text" class="form-control" name="analistaTesteGerminacao" id="analistaTesteGerminacao" required="">  
						</div>
					</div>	

					<div class="row">
						<div class="form-group col-sm-3">
							<label for="temperatura">Temperatura ():</label>
							<input type="number" class="form-control" name="temperatura" id="temperatura" required="">
						</div>

						<div class="form-group col-sm-3">
							<label for="substrato">Substrato:</label>
							<select name ="substrato" id="subtrato" class="form-control" for="substrato" required="">
								<option >Selecione...</option>
								<option value="EP">EP - Substrarto entre papel</option>
								<option value="RP">RP - Substrarto rolo de papel</option>
								<option value="SAL">SAL - Substrarto sobre algodão</option>
								<option value="SE">SE - Substrarto serragem</option>						
								<option value="SS">SS - Substrarto mais seco que o normal</option>						
								<option value="EA">EA - Substrarto entre areia</option>
								<option value="EV">EV - Substrarto sobre vermiculita</option>						
								<option value="SC">SC - Substrarto sobre carvão</option>
								<option value="SV">SV - Substrarto sobre vermiculita</option>
							</select>
						</div>

						<div class="form-group col-sm-3">
							<label for="tratamento">Tratamento:</label>
							<input type="text" class="form-control" name="tratamento" id="tratamento" required="">
						</div>
					</div>
					<div class="row">
						<div class="form-group col-sm-3">
							<label for="numDiasSemeadura">Nº Dias da Semeadura:</label>
							<input type="number" class="form-control" name="numDiasSemeadura" id="numDiasSemeadura" required="">
						</div>

						<div class="form-group col-sm-2">
							<label for="dataLinhaSemeadura">Data:</label> 
							<input type="date" class="form-control" name="dataLinhaSemeadura" id="dataLinhaSemeadura" required="">
						</div>
						<div class="form-group col-sm-1">
							<label for="repeticao1">R1:</label>
							<input type="number" class="form-control" name="repeticao1"  id="repeticao1" required="">
						</div>

						<div class="form-group col-sm-1">
							<label for="repeticao2">R2:</label>
							<input type="number" class="form-control" name="repeticao2"  id="repeticao2" required="">
						</div>
						<div class="form-group col-sm-1">
							<label for="repeticao3">R3:</label>
							<input type="number" class="form-control" name="repeticao3"  id="repeticao3" required="">
						</div>

						<div class="form-group col-sm-1">
							<label for="repeticao4">R4:</label>
							<input type="number" class="form-control" name="repeticao4"  id="repeticao4" required="">
						</div>

						<div class="form-group col-sm-3">
							<label for="totalRepeticao">Total:</label>
							<input type="number" class="form-control" name="totalRepeticao"  id="totalRepeticao" required="">
						</div>
					</div>
					<div class="row">
						<div class="form-group col-sm-12">
							<button class="btn btn-success btn-md" name="acao" value="createTesteGerminacao"><span class="fa fa-plus-square-o"></span> Salvar </button>
						</div>
					</div>

					
				</form>
				
			</div>

			<!---------------------------RESULTADO TESTE GERMINACAO -------------------------------------->	
			<div id="menu4" class="tab-pane fade">
				<h3>Resultado</h3>
				<form name="formCardastroTesteGerminacao" id="formCardastroTesteGerminacao" method="POST" action="crud-amostra.php">
					<div class="row">
						<div class="col-sm-4 ">
							<div class="form-group">
								<label for="loteOrigem">Código:</label> 
								<input type="text" class="form-control" name="codamostra" id="codamostra" value="<?php echo $idamostra?>" readonly="">
							</div>
						</div>
						<div class="col-sm-4 ">
							<div class="form-group">
								<label for="loteOrigem">Lote de Origem:</label> 
								<input type="text" class="form-control" name="loteOrigem" id="loteOrigem" value="<?php echo $idlote?>" disabled="" >
							</div>
						</div>
						<div class="form-group col-sm-4 ">
							<label  for="especie">Especie:</label>
							<input type="text"  class="form-control"  name="especie" id="especie"  value="<?php echo $nomevulgar?>" disabled="">
						</div>
					</div>
					<h4>Total de Plântulas</h4>
					<div class="row">
						<div class="col-sm-2 ">
							<div class="form-group">
								<label for="dataTotalPlantulas">Data:</label> 
								<input type="date" class="form-control" name="dataTotalPlantulas" id="dataTotalPlantulas" required="">
							</div>
						</div>
						<div class="form-group col-sm-2">
							<label for="totalplantulasrepeticao1">R1:</label>
							<input type="number" class="form-control" name="totalplantulasrepeticao1"  id="totalplantulasrepeticao1" onfocus="totalPlantulas()" required="">
						</div>

						<div class="form-group col-sm-2">
							<label for="totalplantulasrepeticao2">R2:</label>
							<input type="number" class="form-control" name="totalplantulasrepeticao2"  id="totalplantulasrepeticao2" onfocus="totalPlantulas()" required="">
						</div>
						<div class="form-group col-sm-2">
							<label for="totalplantulasrepeticao3">R3:</label>
							<input type="number" class="form-control" name="totalplantulasrepeticao3"  id="totalplantulasrepeticao3" onfocus="totalPlantulas()" required="">
						</div>

						<div class="form-group col-sm-2">
							<label for="totalplantulasrepeticao4">R4:</label>
							<input type="number" class="form-control" name="totalplantulasrepeticao4"  id="totalplantulasrepeticao4" onblur="totalPlantulas()" required="">
						</div>
						<div class="form-group col-sm-2">
							<label for="totalplantulasrepeticao">Total:</label>
							<input type="number" class="form-control" name="totalplantulasrepeticao"  id="totalplantulasrepeticao" required="">
						</div>
					</div>
					<h4> Plântulas Anormais</h4>
					<div class="row">
						<div class="col-sm-2 ">
							<div class="form-group">
								<label for="dataPlantulasAnormais">Data:</label> 
								<input type="date" class="form-control" name="dataPlantulasAnormais" id="dataPlantulasAnormais" required="">
							</div>
						</div>
						<div class="form-group col-sm-2">
							<label for="plantulasanormaisrepeticao1">R1:</label>
							<input type="number" class="form-control" name="plantulasanormaisrepeticao1"  id="plantulasanormaisrepeticao1" onfocus="totalPlantulasAnormais()" required="">
						</div>

						<div class="form-group col-sm-2">
							<label for="plantulasanormaisrepeticao2">R2:</label>
							<input type="number" class="form-control" name="plantulasanormaisrepeticao2"  id="plantulasanormaisrepeticao2" onfocus="totalPlantulasAnormais()" required="">
						</div>
						<div class="form-group col-sm-2">
							<label for="plantulasanormaisrepeticao3">R3:</label>
							<input type="number" class="form-control" name="plantulasanormaisrepeticao3"  id="plantulasanormaisrepeticao3" onfocus="totalPlantulasAnormais()" required="">
						</div>

						<div class="form-group col-sm-2">
							<label for="plantulasanormaisrepeticao4">R4:</label>
							<input type="number" class="form-control" name="plantulasanormaisrepeticao4"  id="plantulasanormaisrepeticao4" onblur="totalPlantulasAnormais()" required="">
						</div>
						<div class="form-group col-sm-2">
							<label for="plantulasanormaisrepeticao">Total:</label>
							<input type="number" class="form-control" name="plantulasanormaisrepeticao"  id="plantulasanormaisrepeticao" required="">
						</div>
					</div>
					<h4> Sementes Firmes</h4>
					<div class="row">
						<div class="col-sm-2 ">
							<div class="form-group">
								<label for="dataSementesFirmes">Data:</label> 
								<input type="date" class="form-control" name="dataSementesFirmes" id="dataSementesFirmes" required="">
							</div>
						</div>
						<div class="form-group col-sm-2">
							<label for="sementesfirmesrepeticao1">R1:</label>
							<input type="number" class="form-control" name="sementesfirmesrepeticao1"  id="sementesfirmesrepeticao1" onfocus="totalSementesFirmes()" required="">
						</div>

						<div class="form-group col-sm-2">
							<label for="sementesfirmesrepeticao2">R2:</label>
							<input type="number" class="form-control" name="sementesfirmesrepeticao2"  id="sementesfirmesrepeticao2" onfocus="totalSementesFirmes()" required="">
						</div>
						<div class="form-group col-sm-2">
							<label for="sementesfirmesrepeticao3">R3:</label>
							<input type="number" class="form-control" name="sementesfirmesrepeticao3"  id="sementesfirmesrepeticao3" onfocus="totalSementesFirmes()" required="">
						</div>

						<div class="form-group col-sm-2">
							<label for="sementesfirmesrepeticao4">R4:</label>
							<input type="number" class="form-control" name="sementesfirmesrepeticao4"  id="sementesfirmesrepeticao4" onblur="totalSementesFirmes()" required="">
						</div>
						<div class="form-group col-sm-2">
							<label for="sementesfirmesrepeticao">Total:</label>
							<input type="number" class="form-control" name="sementesfirmesrepeticao"  id="sementesfirmesrepeticao" required="">
						</div>
					</div>
					<h4> Sementes Mortas</h4>
					<div class="row">
						<div class="col-sm-2 ">
							<div class="form-group">
								<label for="dataSementesMortas">Data:</label> 
								<input type="date" class="form-control" name="dataSementesMortas" id="dataSementesMortas" required="">
							</div>
						</div>
						<div class="form-group col-sm-2">
							<label for="sementesmortasrepeticao1">R1:</label>
							<input type="number" class="form-control" name="sementesmortasrepeticao1"  id="sementesmortasrepeticao1" onfocus="totalSementesMortas()" required="">
						</div>

						<div class="form-group col-sm-2">
							<label for="sementesmortasrepeticao2">R2:</label>
							<input type="number" class="form-control" name="sementesmortasrepeticao2"  id="sementesmortasrepeticao2" onfocus="totalSementesMortas()" required="">
						</div>
						<div class="form-group col-sm-2">
							<label for="sementesmortasrepeticao3">R3:</label>
							<input type="number" class="form-control" name="sementesmortasrepeticao3"  id="sementesmortasrepeticao3" onfocus="totalSementesMortas()" required="">
						</div>

						<div class="form-group col-sm-2">
							<label for="sementesmortasrepeticao4">R4:</label>
							<input type="number" class="form-control" name="sementesmortasrepeticao4"  id="sementesmortasrepeticao4" onblur="totalSementesMortas()" required="">
						</div>
						<div class="form-group col-sm-2">
							<label for="sementesmortasrepeticao">Total:</label>
							<input type="number" class="form-control" name="sementesmortasrepeticao"  id="sementesmortasrepeticao" required="">
						</div>
					</div>
					<h4> Sementes Chocas</h4>
					<div class="row">
						<div class="col-sm-2 ">
							<div class="form-group">
								<label for="dataSementesChocas">Data:</label> 
								<input type="date" class="form-control" name="dataSementesChocas" id="dataSementesChocas" required="">
							</div>
						</div>
						<div class="form-group col-sm-2">
							<label for="sementeschocasrepeticao1">R1:</label>
							<input type="number" class="form-control" name="sementeschocasrepeticao1"  id="sementeschocasrepeticao1" onfocus="totalSementesChocas()" required="">
						</div>

						<div class="form-group col-sm-2">
							<label for="sementeschocasrepeticao2">R2:</label>
							<input type="number" class="form-control" name="sementeschocasrepeticao2"  id="sementeschocasrepeticao2" onfocus="totalSementesChocas()" required="">
						</div>
						<div class="form-group col-sm-2">
							<label for="sementeschocasrepeticao3">R3:</label>
							<input type="number" class="form-control" name="sementeschocasrepeticao3"  id="sementeschocasrepeticao3" onfocus="totalSementesChocas()" required="">
						</div>

						<div class="form-group col-sm-2">
							<label for="sementeschocasrepeticao4">R4:</label>
							<input type="number" class="form-control" name="sementeschocasrepeticao4"  id="sementeschocasrepeticao4" onblur="totalSementesChocas()" required="">
						</div>
						<div class="form-group col-sm-2">
							<label for="sementeschocasrepeticao">Total:</label>
							<input type="number" class="form-control" name="sementeschocasrepeticao"  id="sementeschocasrepeticao" required="">
						</div>
					</div>
					<div class="row">
						<div class="form-group col-sm-12">
							<button class="btn btn-success btn-md" name="acao" value="createResultado"><span class="fa fa-plus-square-o"></span> Salvar </button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>



	<?php
	require_once 'footer.php';

	?>


	<script>
		function totalPlantulas(){
			var valor1 = parseInt(document.getElementById('totalplantulasrepeticao1').value);
			var valor2 = parseInt(document.getElementById('totalplantulasrepeticao2').value);
			var valor3 = parseInt(document.getElementById('totalplantulasrepeticao3').value);
			var valor4 = parseInt(document.getElementById('totalplantulasrepeticao4').value);
			document.getElementById('totalplantulasrepeticao').value = valor1 + valor2 + valor3 + valor4;
		}

		function totalPlantulasAnormais(){
			var valor1 = parseInt(document.getElementById('plantulasanormaisrepeticao1').value);
			var valor2 = parseInt(document.getElementById('plantulasanormaisrepeticao2').value);
			var valor3 = parseInt(document.getElementById('plantulasanormaisrepeticao3').value);
			var valor4 = parseInt(document.getElementById('plantulasanormaisrepeticao4').value);
			document.getElementById('plantulasanormaisrepeticao').value = valor1 + valor2 + valor3 + valor4;
		}

		function totalSementesFirmes(){
			var valor1 = parseInt(document.getElementById('sementesfirmesrepeticao1').value);
			var valor2 = parseInt(document.getElementById('sementesfirmesrepeticao2').value);
			var valor3 = parseInt(document.getElementById('sementesfirmesrepeticao3').value);
			var valor4 = parseInt(document.getElementById('sementesfirmesrepeticao4').value);
			document.getElementById('sementesfirmesrepeticao').value = valor1 + valor2 + valor3 + valor4;
		}

		function totalSementesMortas(){
			var valor1 = parseInt(document.getElementById('sementesmortasrepeticao1').value);
			var valor2 = parseInt(document.getElementById('sementesmortasrepeticao2').value);
			var valor3 = parseInt(document.getElementById('sementesmortasrepeticao3').value);
			var valor4 = parseInt(document.getElementById('sementesmortasrepeticao4').value);
			document.getElementById('sementesmortasrepeticao').value = valor1 + valor2 + valor3 + valor4;
		}

		function totalSementesChocas(){
			var valor1 = parseInt(document.getElementById('sementeschocasrepeticao1').value);
			var valor2 = parseInt(document.getElementById('sementeschocasrepeticao2').value);
			var valor3 = parseInt(document.getElementById('sementeschocasrepeticao3').value);
			var valor4 = parseInt(document.getElementById('sementeschocasrepeticao4').value);
			document.getElementById('sementeschocasrepeticao').value = valor1 + valor2 + valor3 + valor4;
		}
	</script>


