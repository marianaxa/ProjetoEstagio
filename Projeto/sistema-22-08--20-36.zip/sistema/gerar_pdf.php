<?php
	//baixar a class mPDF no site http://www.mpdf1.com/mpdf/index.php
	//Descompactar o arquivo na pasta pdf
	include ('pdf/mpdf.php');
	
	require_once 'db_connect.php';	

	require 'crud.php';

	$id = "LC1";

	$lote->select("SELECT idlote_sementes, data_chegada, categoria, nome_vulgar FROM lote, especie WHERE idlote_sementes=$id AND especieFK=id_especie");

	foreach ($loteRecebido->result() as $loteRecebido ){
    $idlote= $loteRecebido['idlote_sementes'];
    $data = $loteRecebido['data_chegada'];
  }



	
	
	$pagina = 
		"<html>
			<body>
				<h1>Informações do Usuário</h1>
				Id: ".$idlote."<br>
				Nome: ".$data."<br>
			</body>
		</html>
		";

$arquivo = "Cadastro01.pdf";

$mpdf = new mPDF();
$mpdf->WriteHTML($pagina);

$mpdf->Output($arquivo, 'I');

// I - Abre no navegador
// F - Salva o arquivo no servido
// D - Salva o arquivo no computador do usuário
?>
