package entidades;


import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


@Entity
public class LoteSemente implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)	
	private int idlote;
	private String fornecedor;
	private String endereco;
	private int renasem;
	private int qtd_lote;
	
	@ManyToOne(cascade= {CascadeType.MERGE}) //Linha com o cÃ³digo correto
	@JoinColumn(name="especieFK")
	private Especie especie;

	public int getIdlote() {
		return idlote;
	}

	public void setIdlote(int idlote) {
		this.idlote = idlote;
	}

	public String getFornecedor() {
		return fornecedor;
	}

	public void setFornecedor(String fornecedor) {
		this.fornecedor = fornecedor;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public int getRenasem() {
		return renasem;
	}

	public void setRenasem(int renasem) {
		this.renasem = renasem;
	}

	public int getQtd_lote() {
		return qtd_lote;
	}

	public void setQtd_lote(int qtd_lote) {
		this.qtd_lote = qtd_lote;
	}

	public Especie getEspecie() {
		return especie;
	}

	public void setEspecie(Especie especie) {
		this.especie = especie;
	}

	
}
