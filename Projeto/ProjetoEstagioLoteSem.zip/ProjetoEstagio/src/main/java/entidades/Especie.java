package entidades;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Especie implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int idespecie;
	private String especie;
	private String nome_cientifico;
	
	public int getIdespecie() {
		return idespecie;
	}
	public void setIdespecie(int idespecie) {
		this.idespecie = idespecie;
	}
	public String getEspecie() {
		return especie;
	}
	public void setEspecie(String especie) {
		this.especie = especie;
	}
	public String getNome_cientifico() {
		return nome_cientifico;
	}
	public void setNome_cientifico(String nome_cientifico) {
		this.nome_cientifico = nome_cientifico;
	}

	
}
