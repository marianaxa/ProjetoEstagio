package controladores;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

@ManagedBean
@ViewScoped
public class mensagemView {
	
	   
    public void save() {
        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage("Operação realizada com sucesso! "));
    }

}
