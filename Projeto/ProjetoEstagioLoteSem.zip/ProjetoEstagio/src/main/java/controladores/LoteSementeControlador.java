package controladores;

import java.io.Serializable;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import entidades.LoteSemente;
import repositorios.EspecieRepositorio;
import repositorios.LoteSementeRepositorio;

@ManagedBean(name="loteMB")
@SessionScoped
public class LoteSementeControlador implements Serializable{

	LoteSementeRepositorio lr = new LoteSementeRepositorio();
	EspecieRepositorio er = new EspecieRepositorio();
	
	LoteSemente lote = new LoteSemente();
	private int id;
	
	List<LoteSemente> listaLote = null;
	List<LoteSemente> listaLoteFiltro = null;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public LoteSemente getLote() {
		return lote;
	}
	public void setLote(LoteSemente lote) {
		this.lote = lote;
	}
	
	public String novoLote() {
		lote = new LoteSemente();
		return "loteCadastro";
	}
	
	public String adicionarLote() {
		lr.adicionar(lote);
		listaLote = null;
		return "loteCadastro";
	}

	
	public List<LoteSemente> getListaLoteFiltro(){
		return listaLoteFiltro;
	}
	
	public void setListaLoteFiltro(List<LoteSemente> listaLoteFiltro) {
		this.listaLoteFiltro = listaLoteFiltro;
	}
	
//	metodo pra retornar uma lista de Lote
	public List<LoteSemente> getListaLote() {
		if(listaLote==null)
			listaLote = lr.listar();
		return listaLote;
	}
	
	public String editarLote(LoteSemente l) {
		lote = l;
		lr.atualizar(lote);
		listaLote = null;
		return "loteFormulario";
	}
	
	public String excluirLote(LoteSemente l) {
		lote = l;
		return "loteConfirmaExclusao";
	}
	
	public String confirmaExclusaoLote() {
		lr.remover(lote);
		listaLote = null;
		return "loteLista";
	}
}
