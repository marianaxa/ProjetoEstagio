package controladores;

import java.io.Serializable;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import repositorios.EspecieRepositorio;
import entidades.Especie;

@ManagedBean(name="especieMB")
@SessionScoped
public class EspecieControlador implements Serializable{

	Especie especie = new Especie();
	EspecieRepositorio er = new EspecieRepositorio();

	public Especie getEspecie() {
		return especie;
	}
	public void setEspecie(Especie especie) {
		this.especie = especie;
	}

	public String novaEspecie() {
		especie = new Especie();
		return "especieFormulario";
	}

	public void save() {
		FacesContext.getCurrentInstance().addMessage(null,
				new FacesMessage("Operação realizada com sucesso! "));
	}	

	public String adicionarEspecie() {
		er.adicionar(especie);
		listaEspecie = null;
		especie = new Especie();
		return "especieFormulario";
	}

	List<Especie> listaEspecie = null;
	List<Especie> listaEspecieFiltro = null;

	public List<Especie> getListaEspecieFiltro(){
		return listaEspecieFiltro;
	}

	public void setListaEspecieFiltro(List<Especie> listaEspecieFiltro) {
		this.listaEspecieFiltro = listaEspecieFiltro;
	}

	public List<Especie> getListaEspecie() {
		if(listaEspecie==null)
			listaEspecie = er.listar();
		return listaEspecie;
	}

	public String editarEspecie(Especie e) {
		especie = e;
		er.atualizar(especie);
		listaEspecie = null;
		return "especieFormulario";
	}

	public String excluirEspecie(Especie e) {
		especie = e;
		return "especieConfirmaExclusao";
	}

	public String confirmaExclusaoEspecie(Especie e) {
		er.remover(especie);
		listaEspecie = null;
		return "especieLista";
	}

}
