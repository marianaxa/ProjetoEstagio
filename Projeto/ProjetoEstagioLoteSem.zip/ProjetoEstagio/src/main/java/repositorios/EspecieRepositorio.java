package repositorios;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import entidades.Especie;

public class EspecieRepositorio {

	private EntityManagerFactory emf;
	private EntityManager em;
	
	public EspecieRepositorio(){
		emf = Persistence.createEntityManagerFactory("ProjetoEstagio");
		em = emf.createEntityManager();
	}
	
	public void adicionar(Especie especie){
		em.getTransaction().begin();
		em.persist(especie);
		em.getTransaction().commit();
	}

	public Especie recuperar(int id){
		return em.find(Especie.class, id);
	}
	public void atualizar(Especie especie){
		em.getTransaction().begin();
		em.merge(especie);
		em.getTransaction().commit();
	}
	public void remover(Especie especie){
		em.getTransaction().begin();
		em.remove(especie);
		em.getTransaction().commit();
	}
	
	public List<Especie> listar() {
		Query qr = em.createQuery("from Especie e");
		return qr.getResultList();
	}

	public void encerrar(){
		em.close();
		emf.close();
	}
	
}
