package repositorios;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import entidades.LoteSemente;
import entidades.LoteSemente;

public class LoteSementeRepositorio {

	private EntityManagerFactory emf;
	private EntityManager em;
	
	public LoteSementeRepositorio(){
		emf = Persistence.createEntityManagerFactory("ProjetoEstagio");
		em = emf.createEntityManager();
	}
	
	public void adicionar(LoteSemente lote){
		em.getTransaction().begin();
		em.persist(lote);
		em.getTransaction().commit();
	}
	public LoteSemente recuperar(int id){
		return em.find(LoteSemente.class, id);
	}
	public void atualizar(LoteSemente lote){
		em.getTransaction().begin();
		em.merge(lote);
		em.getTransaction().commit();
	}
	public void remover(LoteSemente lote){
		em.getTransaction().begin();
		em.remove(lote);
		em.getTransaction().commit();
	}
	
	public List<LoteSemente> listar() {
		Query qr = em.createQuery("from LoteSemente l");
		return qr.getResultList();
	}

	public void encerrar(){
		em.close();
		emf.close();
	}
}
