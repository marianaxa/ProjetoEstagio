package DAO;

import java.util.ArrayList;
import java.util.List;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import ENTITY.Cliente;


public class ClienteDAO {
               private String insertSQL = "insert into cliente values(?,?,?,?,?)";
               private String listSQL="select * from cliente";
               private String updateSQL="update cliente set nome=?,telefone=:?,endereco=? where id=?";
               private String deleteSQL = "delete from cliente where id=?";
               private String getSQL = "select * from cliente where id=?";
       public Cliente getCliente(int Cliente) {
    	   conexaoAlugueis c1 = new conexaoAlugueis();
    	   Cliente a1 = new Cliente();
    	   try {
    		   c1.conectar();
    		   PreparedStatement stm;
    		   stm = c1.getConnection().prepareStatement(getSQL);
    		   stm.setInt(1, Cliente);
    		   ResultSet rs= stm.executeQuery();
    		    while(rs.next()) {
    		    	a1.setidCliente(rs.getInt("Cliente"));
    		    	a1.setNome(rs.getString("Nome"));
    		    	a1.setEndereco(rs.getString("Endereco"));
    		    	a1.setTelefone(rs.getString("Telefone"));
    		    	a1.setCpf(rs.getString("Cpf"));
    		    }
    	   }catch(SQLException SQLE) {
   			JOptionPane.showMessageDialog(null, "Erro na consulta");

    	   }
    	   c1.desconecta();
    	   return a1;
       }
       public void excluir(int Cliente) {
      		conexaoAlugueis c1 = new conexaoAlugueis();
      		try {
      			c1.conectar();
      			PreparedStatement stm;
      			stm = c1.getConnection().prepareStatement(deleteSQL);
      			stm.setInt(1, Cliente);
      			stm.execute();
      			JOptionPane.showMessageDialog(null, "Cliente Deletado");
      		}catch(SQLException sqle) {
      			JOptionPane.showMessageDialog(null, "Nao foi possivel fazer a exclusao");
      		}
      		c1.desconecta();
      	}
       public void atualizar (Cliente c) {
    	   conexaoAlugueis c1 = new conexaoAlugueis();
    	   try {
    		   c1.conectar();
    		   PreparedStatement stm;
   		     stm = c1.getConnection().prepareStatement(updateSQL);
   		     stm.setInt(1, c.getidCliente());
 			 stm.setString(2, c.getNome());
 			stm.setString(3, c.getEndereco());
			stm.setString(4, c.getTelefone());
			stm.setString(5, c.getCpf());

			JOptionPane.showMessageDialog(null, "Atualizado com sucesso");



    	   }catch(SQLException sqle) {
   			JOptionPane.showMessageDialog(null, "Não foi possível atualizar");

    	   }
    	   c1.desconecta();
       }
       public List<Cliente> listar(){
    	   conexaoAlugueis c1 = new conexaoAlugueis();
    	   c1.conectar();
    	   Statement st;
    	   List<Cliente>list = new ArrayList<>();
       
       try {
    	   st = c1.getConnection().createStatement();
			ResultSet rs = st.executeQuery(listSQL);
			while(rs.next()) {
				Cliente c = new Cliente();
				c.setidCliente(rs.getInt(1));
				c.setNome(rs.getString(2));
				c.setEndereco(rs.getString(3));
				c.setTelefone(rs.getString(4));
				c.setCpf(rs.getString(5));
				list.add(c);
			}
		}catch(SQLException sqle) {
			JOptionPane.showMessageDialog(null, "Erro de SQL");
		}catch(Exception e) {
			
		}
		return list;
       }
       
       public void incluir(Cliente c) {
    	   conexaoAlugueis a1 = new conexaoAlugueis();
    	   a1.conectar();
   	    	PreparedStatement ps;
   	    	try {
   				ps = a1.getConnection().prepareStatement(insertSQL);
   				ps.setInt(1,c.getidCliente());
   				ps.setString(2, c.getNome());
   				ps.setString(3, c.getEndereco());
   				ps.setString(4, c.getTelefone());
   				ps.setString(5, c.getCpf());
   				ps.execute();
   			
   				JOptionPane.showMessageDialog(null, "Ok");
   			}catch(SQLException sqle) {
   				sqle.printStackTrace();
   				JOptionPane.showMessageDialog(null, "Erro de SQL aqui");
   			}
   			
   			a1.desconecta();
   		}
    
       
       
       
}
