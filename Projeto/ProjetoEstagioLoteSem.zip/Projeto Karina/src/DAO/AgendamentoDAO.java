package DAO;

public class AgendamentoDAO {
	private String insertSQL = 	"insert into agenda values(?,?,?,?)";
	private String listSQL = "select * from agenda";
}
