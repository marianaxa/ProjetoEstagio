package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class conexaoAlugueis {
     private Connection con;
     Statement stm;
     boolean status;
     
     
     public Connection getConnection() {
    	 return con;
     }
     
     public boolean conectar() {
    	 
    	 String url= "jdbc:mysql://localhost/alugueis";
    	 String usuario = "root";
    	 String senha="root";
    	 try {
    		 
    		 con = DriverManager.getConnection(url,usuario,senha);
    		 stm=con.createStatement();
    		 status=true;
    		 System.out.println("deu bom");
    		 
    	 }catch(SQLException sqle) {
    		 status=false;
    		 System.err.println(sqle.getMessage());
    	 } 
    	 return status;
     }
     public boolean desconecta() {
    	 if(!status) {
    		 System.out.println("Desconectado");
    		 status=true;
    	 }else {
 			try {
 				con.close();
 				status = true;
 				System.out.println("Desconectado!");
 			} catch (SQLException e) {
 				System.out.println(e.getMessage());
 			}
 		}
 		return status;
     }
     public int incluir (String sql) {
    	 int result;
    	 try {
    		 stm=con.createStatement();
    		 result=stm.executeUpdate(sql);
    		 
    	 }catch(SQLException sqle){
 			System.out.println(sqle.getMessage());
 			result = -1;
 		}
 		return result;
     }
     public ResultSet consultar(String sql) {
 		ResultSet rs = null;
 		try {
 			stm = con.createStatement();
 			rs = stm.executeQuery(sql);
 		}catch(SQLException sqle) {
 			System.out.println(sqle.getMessage());
 		}
 		return rs;
 	}
  
     
     
}
