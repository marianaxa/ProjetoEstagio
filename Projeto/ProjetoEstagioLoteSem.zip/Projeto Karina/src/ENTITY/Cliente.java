package ENTITY;

public class Cliente {
	  private int idCliente;
	   private String nome;
	   private String telefone;
	   private String cpf;
	   public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	private String endereco;
	public int getidCliente() {
		return idCliente;
	}
	public void setidCliente(int aluguel) {
	this.idCliente = aluguel;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}





}
