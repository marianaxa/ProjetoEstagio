package GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JMenuBar;
import java.awt.SystemColor;

public class Login extends JFrame implements ActionListener{

	private JPanel contentPane;
  //  private TabelaCliente model;
	/**
	 * Launch the application.
	 */

//DIA 13!!<<<<< REQUISITOS,CLASSES E PROT�TIPO!!!! DIA 27 >> CODIGO CRUD ,, 18>>>ENTREGA DO TRABALHO
	/**
	 * Create the frame.
	 */		
	JButton btnCadastramento = new JButton("Cadastramento");

	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setForeground(Color.BLUE);
		menuBar.setBackground(Color.BLUE);
		setJMenuBar(menuBar);
		btnCadastramento.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		btnCadastramento.setForeground(Color.BLUE);
		btnCadastramento.setBackground(SystemColor.menu);
		menuBar.add(btnCadastramento);
		
		JButton btnAgendamento = new JButton("Agendamento");
		btnAgendamento.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		btnAgendamento.setBackground(SystemColor.menu);
		btnAgendamento.setForeground(Color.BLUE);
		menuBar.add(btnAgendamento);
		
		
		
		JButton btnConsulta = new JButton("Consultas");
		btnConsulta.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		btnConsulta.setForeground(Color.BLUE);
		btnConsulta.setBackground(SystemColor.menu);
		menuBar.add(btnConsulta);
		btnConsulta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		JButton btnDisponibilidades = new JButton("Dias  Disponiveis");
		btnDisponibilidades.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		btnDisponibilidades.setForeground(Color.BLUE);
		btnDisponibilidades.setBackground(SystemColor.menu);
		menuBar.add(btnDisponibilidades);

		btnCadastramento.addActionListener(this);
		contentPane = new JPanel();
		contentPane.setBackground(Color.LIGHT_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblbemvindo = new JLabel("BEM VINDO - ESPA\u00C7O DE PAULA");
		lblbemvindo.setFont(new Font("Century Gothic", Font.PLAIN, 14));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
					.addGap(87)
					.addComponent(lblbemvindo, GroupLayout.PREFERRED_SIZE, 244, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(93, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblbemvindo, GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(166, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}
	   public void actionPerformed(ActionEvent e) {
		if(e.getSource()==btnCadastramento) {
		    	TabelaClient t = new TabelaClient(); // chamando uma outra classe
	     	t.setVisible(true);
	       
		} 
	}
		public static void main(String[] args) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						Login frame = new Login();
						frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		}


	
}
