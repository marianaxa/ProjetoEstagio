package GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import DAO.ClienteDAO;
import ENTITY.Cliente;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;

public class CadastroCliente extends JFrame {

	private JPanel contentPane;
	private JTextField tfcliente;
	private JTextField tfnome;
	private JTextField tfend;
	private JTextField tftel;
	private JTextField tfcpf;


	public CadastroCliente(DefaultTableModel model) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblCliente = new JLabel("Cliente:");
		
		tfcliente = new JTextField();
		tfcliente.setColumns(10);
		
		JLabel lblNome = new JLabel("Nome:");
		
		JLabel lblEndereco = new JLabel("Endereco:");
		
		JLabel lblTelefone = new JLabel("Telefone:");
		
		JLabel lblCpf = new JLabel("Cpf:");
		
		tfnome = new JTextField();
		tfnome.setColumns(10);
		
		tfend = new JTextField();
		tfend.setColumns(10);
		
		tftel = new JTextField();
		tftel.setColumns(10);
		
		tfcpf = new JTextField();
		tfcpf.setColumns(10);
		
		JButton btnVoltar = new JButton("voltar");
		
		JButton btnIncluir = new JButton("Incluir");
		btnIncluir.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnIncluir) {
					ClienteDAO cdao = new ClienteDAO();
				   Cliente c = new Cliente();
				   c.setidCliente(Integer.parseInt(tfcliente.getText()));
				   c.setNome(tfnome.getText());
				   c.setEndereco(tfend.getText());
				   c.setTelefone(tftel.getText()); c.setCpf(tfcpf.getText());
	               cdao.incluir(c);
	               TabelaClient.carregarDados(model);
	               setVisible(false);
				   
				}				
			}
				
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addContainerGap()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(lblTelefone)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(tftel, GroupLayout.PREFERRED_SIZE, 149, GroupLayout.PREFERRED_SIZE)
									.addGap(31)
									.addComponent(lblCpf)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(tfcpf, GroupLayout.PREFERRED_SIZE, 102, GroupLayout.PREFERRED_SIZE))
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
									.addGroup(gl_contentPane.createSequentialGroup()
										.addComponent(lblCliente)
										.addPreferredGap(ComponentPlacement.RELATED)
										.addComponent(tfcliente, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
									.addGroup(gl_contentPane.createSequentialGroup()
										.addComponent(lblNome)
										.addGap(18)
										.addComponent(tfnome, GroupLayout.PREFERRED_SIZE, 264, GroupLayout.PREFERRED_SIZE))
									.addGroup(gl_contentPane.createSequentialGroup()
										.addComponent(lblEndereco)
										.addPreferredGap(ComponentPlacement.RELATED)
										.addComponent(tfend)))))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(72)
							.addComponent(btnVoltar)
							.addGap(99)
							.addComponent(btnIncluir)))
					.addContainerGap(51, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblCliente)
						.addComponent(tfcliente, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(45)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNome)
						.addComponent(tfnome, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblEndereco)
						.addComponent(tfend, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(29)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblTelefone)
						.addComponent(tftel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblCpf)
						.addComponent(tfcpf, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnVoltar)
						.addComponent(btnIncluir))
					.addContainerGap())
		);
		contentPane.setLayout(gl_contentPane);
	  }
	}
