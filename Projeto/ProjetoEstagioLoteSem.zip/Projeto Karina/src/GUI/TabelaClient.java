package GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import DAO.ClienteDAO;
import ENTITY.Cliente;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;

public class TabelaClient extends JFrame {
	private DefaultTableModel modelT = new DefaultTableModel();//Depois da aula.

	private JPanel contentPane;
	private JTable table;
	private JButton btnNewButton = new JButton("Novo Cadastro");
	private JButton btnExcluir = new JButton("Deletar Cadastro");;

	JButton btnAtualizar = new JButton("Atualizar");
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TabelaClient frame = new TabelaClient();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public static void carregarDados(DefaultTableModel model) {
		model.setNumRows(0);
		ClienteDAO cdao=new ClienteDAO();
		List<Cliente>list =cdao.listar();
		for(Cliente c :list) {
			model.addRow(new Object[] {c.getidCliente(),
					c.getNome(),
					c.getEndereco(),
					c.getTelefone(),
					c.getCpf(),
			});
		}
	}
	/**
	 * Create the frame.
	 */
	public TabelaClient() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		
		table = new JTable(modelT);
		modelT.addColumn("Cliente");
		modelT.addColumn("Nome");
		modelT.addColumn("endereco");
		modelT.addColumn("telefone");
		modelT.addColumn("Cpf");
		carregarDados(modelT);
		scrollPane.setViewportView(table);

     //   JButton btnNovoCadastro = new JButton("Novo Cadastro");	
		
			btnNewButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {	
						if(e.getSource()==btnNewButton) {
							CadastroCliente c = new CadastroCliente(modelT);
							c.setVisible(true);
						}
					}
			});
				
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			 
				int linha = table.getSelectedRow();
				int cliente = (int)table.getValueAt(linha, 0);
				ClienteDAO cdao = new ClienteDAO();
				cdao.excluir(cliente);
				TabelaClient.carregarDados(modelT);
			  
			}
			
		});
								
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addContainerGap(34, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(btnNewButton)
							.addGap(18)
							.addComponent(btnExcluir)
							.addGap(44)
							.addComponent(btnAtualizar))
						.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 347, GroupLayout.PREFERRED_SIZE))
					.addGap(43))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addGap(54)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton)
						.addComponent(btnExcluir)
						.addComponent(btnAtualizar))
					.addPreferredGap(ComponentPlacement.RELATED, 53, Short.MAX_VALUE)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 111, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
		);
		
		contentPane.setLayout(gl_contentPane);
	}
}
