package repositorios;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import entidades.Lote;

public class LoteRepositorio {

	private EntityManagerFactory emf;
	private EntityManager em;
	
	public LoteRepositorio(){
		emf = Persistence.createEntityManagerFactory("ProjetoEstagio");
		em = emf.createEntityManager();
	}
	
	public void adicionar(Lote lote){
		em.getTransaction().begin();
		em.persist(lote);
		em.getTransaction().commit();
	}
	public Lote recuperar(int id){
		return em.find(Lote.class, id);
	}
	public void atualizar(Lote lote){
		em.getTransaction().begin();
		em.merge(lote);
		em.getTransaction().commit();
	}
	public void remover(Lote lote){
		em.getTransaction().begin();
		em.remove(lote);
		em.getTransaction().commit();
	}
	
	public List<Lote> listar() {
		Query qr = em.createQuery("from Lote c");
		return qr.getResultList();
	}

	public void encerrar(){
		em.close();
		emf.close();
	}
}
