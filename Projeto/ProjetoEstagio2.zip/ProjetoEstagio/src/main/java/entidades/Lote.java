package entidades;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

	@Entity
	public class Lote  implements Serializable{

		private static final long serialVersionUID = 1L;
		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		private int idlote;
		private String fornecedor;
		private String endereco;
		private int qtd_lotes;
		private String renasem;
		
		public int getIdlote() {
			return idlote;
		}
		public void setIdlote(int idlote) {
			this.idlote = idlote;
		}
		public String getFornecedor() {
			return fornecedor;
		}
		public void setFornecedor(String fornecedor) {
			this.fornecedor = fornecedor;
		}
		public String getEndereco() {
			return endereco;
		}
				
		public int getQtd_lotes() {
			return qtd_lotes;
		}
		public void setQtd_lotes(int qtd_lotes) {
			this.qtd_lotes = qtd_lotes;
		}
		public void setEndereco(String endereco) {
			this.endereco = endereco;
		}
		public String getRenasem() {
			return renasem;
		}
		public void setRenasem(String renasem) {
			this.renasem = renasem;
		}
		
		
		
}
