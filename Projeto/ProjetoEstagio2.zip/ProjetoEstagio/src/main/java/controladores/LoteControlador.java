package controladores;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import entidades.Curso;
import entidades.Lote;
import repositorios.CursoRepositorio;
import repositorios.LoteRepositorio;

@ManagedBean(name="loteMB")
@SessionScoped
public class LoteControlador {

	Lote lote = new Lote();
	LoteRepositorio lr = new LoteRepositorio();
	public Lote getLote() {
		return lote;
	}
	public void setLote(Lote lote) {
		this.lote = lote;
	}
	
	public String novoLote() {
		lote = new Lote();
		return "loteFormulario";
	}
	
	public String adicionarLote() {
		lr.adicionar(lote);
		listaLote = null;
		return "principal";
	}

	List<Lote> listaLote = null;
}
