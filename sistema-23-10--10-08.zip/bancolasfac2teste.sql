CREATE DATABASE  IF NOT EXISTS `lasfac2` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `lasfac2`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: lasfac2
-- ------------------------------------------------------
-- Server version	5.7.19-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `amostra`
--

DROP TABLE IF EXISTS `amostra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `amostra` (
  `idamostra` int(11) NOT NULL AUTO_INCREMENT,
  `condicao_armazenamento` varchar(45) DEFAULT NULL,
  `data_implantacao` varchar(10) DEFAULT NULL,
  `amostrador` varchar(45) DEFAULT NULL,
  `renasem_amostrador` varchar(45) DEFAULT NULL,
  `peneira` varchar(45) DEFAULT NULL,
  `representatividade` varchar(45) DEFAULT NULL,
  `loteFK` varchar(13) DEFAULT NULL,
  `situacao` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idamostra`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;



--
-- Table structure for table `arvore`
--

DROP TABLE IF EXISTS `arvore`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `arvore` (
  `idarvores` int(11) NOT NULL AUTO_INCREMENT,
  `altura_total` decimal(5,0) DEFAULT NULL,
  `altura_comercial` decimal(5,0) DEFAULT NULL,
  `dap` decimal(10,0) DEFAULT NULL,
  `cap` decimal(10,0) DEFAULT NULL,
  `gpsX` varchar(45) DEFAULT NULL,
  `gpsY` varchar(45) DEFAULT NULL,
  `tipo_colheita` varchar(45) DEFAULT NULL,
  `tipo_solo` varchar(45) DEFAULT NULL,
  `tipo_terreno` varchar(45) DEFAULT NULL,
  `localizacao` varchar(45) DEFAULT NULL,
  `tipo_vegetacao` varchar(45) DEFAULT NULL,
  `arvores_vizinhas` tinytext,
  `colheitaFK` int(11) DEFAULT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idarvores`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `categoria_usuario`
--

DROP TABLE IF EXISTS `categoria_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categoria_usuario` (
  `idcat_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `nome_cat_usuario` varchar(45) NOT NULL,
  PRIMARY KEY (`idcat_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;



--
-- Table structure for table `checagem`
--

DROP TABLE IF EXISTS `checagem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `checagem` (
  `idchecagem` int(11) NOT NULL AUTO_INCREMENT,
  `ndias_semeadura` varchar(45) NOT NULL,
  `data` varchar(45) NOT NULL,
  `germinacaoFK` int(11) NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idchecagem`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;



--
-- Table structure for table `colheita`
--

DROP TABLE IF EXISTS `colheita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `colheita` (
  `idcolheita` int(11) NOT NULL AUTO_INCREMENT,
  `data` date NOT NULL,
  `local` varchar(255) NOT NULL,
  `colhedores` varchar(255) NOT NULL,
  `especieFK` int(11) DEFAULT NULL,
  `observacoes_colheita` varchar(255) DEFAULT '...',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idcolheita`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `endereco`
--

DROP TABLE IF EXISTS `endereco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `endereco` (
  `id_endereco` int(11) NOT NULL AUTO_INCREMENT,
  `rua` varchar(100) NOT NULL,
  `bairro` varchar(100) NOT NULL,
  `cidade` varchar(45) NOT NULL,
  `estado` varchar(2) NOT NULL,
  `cep` varchar(45) NOT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_endereco`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;



--
-- Table structure for table `especie`
--

DROP TABLE IF EXISTS `especie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `especie` (
  `id_especie` int(11) NOT NULL AUTO_INCREMENT,
  `nome_cientifico` varchar(45) NOT NULL,
  `nome_vulgar` varchar(45) NOT NULL,
  `familia` varchar(45) NOT NULL,
  `num_repeticoes` int(1) DEFAULT '4',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_especie`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;



--
-- Table structure for table `fornecedor`
--

DROP TABLE IF EXISTS `fornecedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fornecedor` (
  `id_fornecedor` int(11) NOT NULL AUTO_INCREMENT,
  `nome_fornecedor` varchar(225) NOT NULL,
  `renasem` varchar(45) NOT NULL,
  `telefone` varchar(45) DEFAULT NULL,
  `enderecoFK` int(11) DEFAULT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_fornecedor`),
  KEY `fk_endereco` (`enderecoFK`),
  CONSTRAINT `fk_endereco` FOREIGN KEY (`enderecoFK`) REFERENCES `endereco` (`id_endereco`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;



--
-- Table structure for table `germ_resultado`
--

DROP TABLE IF EXISTS `germ_resultado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `germ_resultado` (
  `idgerm_resultado` int(11) NOT NULL AUTO_INCREMENT,
  `descrepeticao` varchar(3) DEFAULT NULL,
  `porcent_germinacao` varchar(10) DEFAULT NULL,
  `velocidade_germinacao` varchar(10) DEFAULT NULL,
  `plantulas_normais` varchar(10) DEFAULT NULL,
  `plantulas_anormais` varchar(10) DEFAULT NULL,
  `sementes_duras` varchar(10) DEFAULT NULL,
  `semenstes_dormentes` varchar(10) DEFAULT NULL,
  `sementes_mortas` varchar(10) DEFAULT NULL,
  `germinacaoFK` varchar(45) NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idgerm_resultado`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;



--
-- Table structure for table `germinacao`
--

DROP TABLE IF EXISTS `germinacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `germinacao` (
  `idgerminacao` int(11) NOT NULL AUTO_INCREMENT,
  `datasemeadura` varchar(10) NOT NULL,
  `analista` varchar(45) NOT NULL,
  `temperatura` varchar(45) NOT NULL,
  `substrato` varchar(45) NOT NULL,
  `numsementes_repeticao` varchar(10) NOT NULL,
  `numrepeticoes` varchar(45) NOT NULL,
  `peso_amostra_germinacao` varchar(45) NOT NULL,
  `tratamento` varchar(45) NOT NULL,
  `obs_germinacao` tinytext,
  `amostraFK` int(11) NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idgerminacao`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `lote`
--

DROP TABLE IF EXISTS `lote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lote` (
  `idlote_sementes` varchar(13) NOT NULL,
  `especie` varchar(45) DEFAULT NULL,
  `data_chegada` varchar(10) NOT NULL,
  `categoria` varchar(20) DEFAULT NULL,
  `origemFK` int(11) DEFAULT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `especieFK` int(11) DEFAULT NULL,
  PRIMARY KEY (`idlote_sementes`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `num_sementes`
--

DROP TABLE IF EXISTS `num_sementes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `num_sementes` (
  `idteste_num_sementes` int(11) NOT NULL AUTO_INCREMENT,
  `data_num_sementes` varchar(10) NOT NULL,
  `analista_num_sementes` varchar(45) NOT NULL,
  `qtd_num_sementes` float NOT NULL,
  `peso_amostra` float NOT NULL,
  `kg_num_sementes` float NOT NULL,
  `observacoes_num_sementes` varchar(255) DEFAULT NULL,
  `amostraFK` int(11) NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idteste_num_sementes`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `outras_sementes`
--

DROP TABLE IF EXISTS `outras_sementes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `outras_sementes` (
  `idoutras_sementes` int(11) NOT NULL AUTO_INCREMENT,
  `dt_outras_sementes` varchar(10) NOT NULL,
  `analista_outras_sementes` varchar(45) NOT NULL,
  `peso_amostra_os` varchar(45) NOT NULL,
  `outras_especies` varchar(45) NOT NULL,
  `sementes_silvestres` varchar(45) NOT NULL,
  `sementes_toleradas` varchar(45) NOT NULL,
  `sementes_proibidas` varchar(45) NOT NULL,
  `obs_outras_sementes` varchar(45) DEFAULT NULL,
  `amostraFK` int(11) NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idoutras_sementes`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;



--
-- Table structure for table `pesagem_teor_agua`
--

DROP TABLE IF EXISTS `pesagem_teor_agua`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pesagem_teor_agua` (
  `idpesagem_teor_agua` int(11) NOT NULL AUTO_INCREMENT,
  `num_cadinho` int(11) NOT NULL,
  `peso_cadinho` varchar(10) NOT NULL,
  `peso_umido` varchar(10) NOT NULL,
  `peso_seco` varchar(10) NOT NULL,
  `umidade` varchar(10) NOT NULL,
  `teor_aguaFK` int(11) NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idpesagem_teor_agua`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;



--
-- Table structure for table `peso_mil_sementes`
--

DROP TABLE IF EXISTS `peso_mil_sementes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `peso_mil_sementes` (
  `idpeso_mil_sementes` int(11) NOT NULL AUTO_INCREMENT,
  `data_ensaio` varchar(10) NOT NULL,
  `analista_mil_sementes` varchar(45) NOT NULL,
  `peso_medio` varchar(45) NOT NULL,
  `desvio_padrao` varchar(45) NOT NULL,
  `variancia` varchar(45) NOT NULL,
  `coeficiente_variacao` varchar(45) NOT NULL,
  `kg_mil_sementes` varchar(45) NOT NULL,
  `kg_num_medio` varchar(45) NOT NULL,
  `peso_amostra` varchar(45) NOT NULL,
  `obs_peso_mil_sementes` tinytext,
  `amostraFK` int(11) NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idpeso_mil_sementes`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;



--
-- Table structure for table `pureza`
--

DROP TABLE IF EXISTS `pureza`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pureza` (
  `idpureza` int(11) NOT NULL AUTO_INCREMENT,
  `data_ensaio` varchar(10) NOT NULL,
  `analista` varchar(45) NOT NULL,
  `peso_amostra_media` varchar(10) NOT NULL,
  `peso_amostra_trab` varchar(10) NOT NULL,
  `sementes_puras` varchar(10) NOT NULL,
  `outras_sementes` varchar(10) NOT NULL,
  `material_inerte` varchar(10) NOT NULL,
  `natureza_material_inerte` varchar(45) NOT NULL,
  `outras_cultivares` varchar(10) NOT NULL,
  `obs_pureza` tinytext,
  `amostraFK` int(11) NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idpureza`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;



--
-- Table structure for table `repeticao`
--

DROP TABLE IF EXISTS `repeticao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repeticao` (
  `idrepeticao` int(11) NOT NULL AUTO_INCREMENT,
  `descricaorep` varchar(45) DEFAULT NULL,
  `qtdgerminada` int(11) DEFAULT NULL,
  `checagemFK` int(11) DEFAULT NULL,
  PRIMARY KEY (`idrepeticao`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `repeticao_mil_sementes`
--

DROP TABLE IF EXISTS `repeticao_mil_sementes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repeticao_mil_sementes` (
  `idrepeticao_mil_sementes` int(11) NOT NULL AUTO_INCREMENT,
  `descricao_rep` varchar(45) NOT NULL,
  `peso_amostra_rep` varchar(10) NOT NULL,
  `peso_mil_sementesFK` int(11) NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idrepeticao_mil_sementes`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;



--
-- Table structure for table `teor_agua`
--

DROP TABLE IF EXISTS `teor_agua`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teor_agua` (
  `idteor_agua` int(11) NOT NULL AUTO_INCREMENT,
  `data_teor_agua` varchar(10) NOT NULL,
  `analista_teor_agua` varchar(45) NOT NULL,
  `obs_teor_agua` tinytext,
  `umidade_media` varchar(45) DEFAULT NULL,
  `amostraFK` int(11) NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `peso_amostra_umi` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idteor_agua`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `idusuario` int(11) NOT NULL AUTO_INCREMENT,
  `nome_usuario` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `senha` varchar(45) DEFAULT NULL,
  `categoriaUsuarioFK` int(11) DEFAULT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idusuario`),
  KEY `fk_categoria_usuario` (`categoriaUsuarioFK`),
  CONSTRAINT `fk_categoria_usuario` FOREIGN KEY (`categoriaUsuarioFK`) REFERENCES `categoria_usuario` (`idcat_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Dumping routines for database 'lasfac2'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-10-23 10:03:43
