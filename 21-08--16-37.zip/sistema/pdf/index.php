<?php
header('Content-type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
 <!-- <meta charset="utf-8"> -->
  <title>Boletim de An�lise</title>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <link href="/estilo.css" rel="stylesheet" type="text/css">
</head>

<script>window.print();</script>

<body bgcolor="#ffffff">
	<br>
	<center>
   <table  width="100%" class="tabela" align="center">
    <tr> 
      <td colspan="2" align="middle"><h2>BOLETIM DE AN�LISE DE SEMENTES N�</h2><span></span></td>
    </tr>
  </table>
  <br><br>

  <table  width="100%" class="tabela" align="center"> 
    <tr style="COLOR: #000080">
     <td align="center" bgcolor="#f2f2f2" colspan="2"><b>IDENTIFICA��O DO REQUERENTE</b></td>
   </tr>    	
   <!--Esses dados provavelmente vem de um pre cadastro-->
   <tr>
     <td width="50%"><b>Requerente:</b> </td>
     <td><b>N� RENASEM:</b> </td>
   </tr>

   <tr>
    <td width="50%"><b>Endere�o:</b> </td>
  </tr>
</table>
<br><br>  

<table width="100%" class="tabela" align="center">
  <tr style="COLOR: #000080">
    <td align="center" bgcolor="#f2f2f2" colspan="8"><b>BOVINOS</b></td>
  </tr>
  <tr>
    <td colspan="2" width="20%" height="19" align="middle"><div align="center"><center><p>0 - 12 meses</p></center></div></td>
    <td colspan="2" width="20%" height="19" align="middle"><div align="center"><center>
     <p>13 - 24 meses</p>
   </center></div>
 </td>
 <td colspan="2" width="20%" height="19" align="middle"><div align="center"><center>
   <p>25 - 36 meses</p>
 </center></div>
</td>
<td colspan="2" height="19" width="20%" align="middle"><div align="center"><center><p>Mais de 36 meses</p></center></div></td>
</tr>
<tr align="middle">
  <td height="15">M 
   <input type=text  size="5" value="0" disabled class="text">
 </td>
 <td height="15">F 
   <input type=text  size="5" value="0" disabled class="text">
 </td>
 <td height="15">M 
   <input type=text  size="5" value="0" disabled class="text">
 </td>
 <td height="15">F 
   <input type=text  size="5" value="0" disabled class="text">
 </td>
 <td height="15">M 
   <input type=text  size="5" value="0" disabled class="text">
 </td>
 <td height="15">F 
   <input type=text  size="5" value="0" disabled class="text">
 </td>
 <td height="15">M 
   <input type=text  size="5" value="0" disabled class="text">
 </td>
 <td height="15">F 
   <input type=text  size="5" value="0" align=center disabled class="text">
 </td>
 <tr align="middle">
   <td height="19" colspan="3" align="right">TOTAL DE BOVINOS</td>
   <td colspan="3" height="23" align="left">
    <input type=text size="10" value="0" disabled class="text">
  </td>
</tr>
</table>

<table width="100%" class="tabela" align="center">
 <!-- VACINA��O DE FEBRE AFTOSA -->
 <tr>
  <td colspan=11>&nbsp;</td>
</tr> 

<tr style="COLOR: #000080" align=center>
  <td colspan=11 align=center bgcolor="#f2f2f2"><b>VACINAS FEBRE AFTOSA(BOVINOS)</b></td>
</tr>
<tr>
 <td align=middle><b>Data Compra</td>
   <td colspan=2 align=middle><b>Num. Documento</td>
     <td colspan=2 align=middle><b>Validade Vacina</td>
       <td colspan=2 align=middle><b>Quantidade Vacinada</td>
         <td colspan=2 align=middle><b>Data Vacina��o</td>
           <td colspan=2 align=middle><b>Campanha</td>
           </tr>

           <tr>
            <td align=middle>27/11/2017</td>
            <td colspan=2 align=middle>1770</td>
            <td colspan=2 align=middle>01/01/2019</td>
            <td colspan=2 align=middle>
             11
           </td>
           <td colspan=2 align=middle>27/11/2017</td>
           <td colspan=2 align=middle width="200">2/2017 - 38� Campanha de Febre Aftosa</td>
         </tr>

         <tr>
          <td align=middle>30/05/2017</td>
          <td colspan=2 align=middle>44</td>
          <td colspan=2 align=middle>01/02/2018</td>
          <td colspan=2 align=middle>
           11
         </td>
         <td colspan=2 align=middle>30/05/2017</td>
         <td colspan=2 align=middle width="200">1/2017 - 37� Campanha de Febre Aftosa</td>
       </tr>

       <tr>
        <td align=middle>16/11/2016</td>
        <td colspan=2 align=middle>22819</td>
        <td colspan=2 align=middle>01/12/2017</td>
        <td colspan=2 align=middle>
         11
       </td>
       <td colspan=2 align=middle>17/11/2016</td>
       <td colspan=2 align=middle width="200">2/2016 - 36� Campanha de Febre Aftosa</td>
     </tr>


     <!-- VACINA��O ANTI-R�BICA -->
     <tr>
      <td colspan=11>&nbsp;</td>
    </tr> 

    <tr style="COLOR: #000080" align=center>
      <td colspan=11 align=center bgcolor="#f2f2f2"><b>VACINAS ANTI-R�BICA(BOVINOS)</b></td>
    </tr>
    <tr align=center>
      <td colspan=11 align=center><br><b>Nenhuma vacina cadastrada.<br><br></td>
      </tr>

    </table>
    <table width="100%" class="tabela" align="center">
     <!-- VACINA��O DE BRUCELOSE -->

     <tr style="COLOR: #000080" align=center>
      <td colspan=12 align=center bgcolor="#f2f2f2"><b>VACINAS BRUCELOSE(BOVINOS)</b></td>
    </tr>
    <tr>
     <td align=middle><b>Data Compra</td>
       <td colspan=2 align=middle><b>Num. Documento</b></td>
       <td colspan=2 align=middle><b>Validade Vacina</b></td>
       <td colspan=2 align=middle><b>Quantidade Vacinada</b></td>
       <td colspan=2 align=middle><b>Data Vacina��o</b></td>
     </tr>

     <tr>
      <td align=middle>30/11/2013</td>
      <td colspan=2 align=middle>704</td>
      <td colspan=2 align=middle>01/05/2014</td>
      <td colspan=2 align=middle>150</td>
      <td colspan=2 align=middle>05/12/2013</td>
    </tr>

  </table>
  <br>

  <table width="100%" class="tabela" align="center">
    <tr style="COLOR: #000080">
      <td align="center" bgcolor="#f2f2f2" colspan="11"><b>BUBALINOS</b></td>
    </tr>
    <tr>
      <td colspan="2" height="19" align="middle" width="20%"><div align="center"><center><p>0 - 12 meses</p></center></div></td>
      <td colspan="2" height="19" align="middle" width="20%"><div align="center"><center>
       <p>13 - 24 meses</p>
     </center></div>
   </td>
   <td colspan="2" height="19" align="middle" width="20%"><div align="center"><center>
     <p>25 - 36 meses</p>
   </center></div>
 </td>
 <td colspan="2" height="19" align="middle" width="20%"><div align="center"><center><p>Mais de 36 meses</p></center></div></td>
</tr>
<tr align="middle">
  <td height="15">M 
   <input type=text  size="5" value="0" disabled id=text4 name=text4 class="text">
 </td>
 <td height="15">F 
   <input type=text  size="5" value="0" disabled id=text5 name=text5 class="text">
 </td>
 <td height="15">M 
   <input type=text  size="5" value="0" disabled id=text6 name=text6 class="text">
 </td>
 <td height="15">F 
   <input type=text  size="5" value="0" disabled id=text7 name=text7 class="text">
 </td>
 <td height="15">M 
   <input type=text  size="5" value="0" disabled id=text8 name=text8 class="text">
 </td>
 <td height="15">F 
   <input type=text  size="5" value="0" disabled id=text9 name=text9 class="text">
 </td>
 <td height="15">M 
   <input type=text  size="5" value="0" disabled id=text10 name=text10 class="text">
 </td>
 <td height="15">F 
   <input type=text  size="5" value="0" align=center disabled id=text11 name=text11 class="text">
 </td>
</tr>
<tr align="middle">
  <td height="19" colspan="3" align="right">TOTAL DE BUBALINOS</td>
  <td colspan="8" height="23" align="left">
   <input type=text size="10" value="0" disabled id=text12 name=text12 class="text">
 </td>
</tr>
</table>
<br>
<table width="100%" class="tabela" align="center">

  <tr style="COLOR: #000080" align=center>
    <td colspan="11" align="center" bgcolor="#f2f2f2"><b>VACINAS FEBRE AFTOSA(BUBALINOS)</b></td>
  </tr>
  <tr align=center>
   <td colspan=11 align=center ><br><b>N�o Existem Vacinas Cadastradas<br><br></td>
   </tr>

 </table>
 <Br>
 <table width="100%" class="tabela" align="center">

  <tr style="COLOR: #000080" align=center>
    <td colspan=11 align=center bgcolor="#f2f2f2"><b>VACINAS ANTI-R�BICA(BUBALINOS)</b></td>
  </tr>
  <tr align=center>
   <td colspan=11 align=center ><br><b>N�o Existem Vacinas Cadastradas<br><br></td>
   </tr>

 </table>
 <table width="100%" class="tabela" align="center">

  <tr style="COLOR: #000080" align=center>
    <td colspan=10 align=center bgcolor="#f2f2f2"><b>VACINAS BRUCELOSE(BUBALINOS)</b></td>
  </tr>
  <tr align=center>
   <td colspan=9 align=center ><br><b>N�o Existem Vacinas Brucelose Cadastradas<br><br></td>
   </tr>

 </table>
 <br>


 <br>
 <center>
  <br><br>

  <h3>______________________________________________________________
   <b> <br>Willy Silva de Souza 
     <br> Analista de Sistemas</b></h3>
     <H3>DATA DA DECLARA��O: 20/8/2018</h3>
     </center>

   </center></div>
 </body>
 </html>