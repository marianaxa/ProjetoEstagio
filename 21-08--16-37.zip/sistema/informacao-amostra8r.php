<?php 
require_once 'header.php';
require 'crud.php';

$idamostra = $_GET['idamostra'];
$amostra = new Crud();
$tbnumerosementes = new Crud();
$tbteoragua = new Crud();

$amostra->select("SELECT idlote_sementes, data_chegada, categoria, nome_vulgar, nome_cientifico, familia, condicao_armazenamento, data_implantacao FROM amostra, lote, especie WHERE idamostra=$idamostra and loteFK=idlote_sementes and especieFK=id_especie ");

foreach ($amostra->result() as $amostra ){
	$idlote = $amostra['idlote_sementes'];
	$dtchegada = $amostra['data_chegada'];
	$categoria = $amostra['categoria'];
	$nomevulgar= $amostra['nome_vulgar'];
	$nomecientifico = $amostra['nome_cientifico'];
	$familia = $amostra['familia'];
	$armazenamento = $amostra['condicao_armazenamento'];
	$dtimplantacao = $amostra['data_implantacao'];
}

$tbnumerosementes->select('SELECT * FROM teste_num_sementes WHERE amostraFK ='.$idamostra);

$tbteoragua->select('SELECT * FROM teste_teor_agua WHERE amostraFK ='.$idamostra);

?>

<!-- Essa janela é igual a outra mas é para as amostras q tem 8 repeticoes -->
<div class="container">
	<h2>Amostra</h2>

	<ul class="nav nav-tabs">
		<li class="active"><a data-toggle="tab" href="#home">Dados da Amostra</a></li>
		<li><a data-toggle="tab" href="#menu1">Número de Sementes</a></li>
		<li><a data-toggle="tab" href="#menu2">Análise Teor de Água</a></li>
		<li><a data-toggle="tab" href="#menu3">Análise da Germinação</a></li>
	</ul>

	<div class="tab-content">
		<div id="home" class="tab-pane fade in active">
			<h3>Dados da Amostra</h3>
			<div class="row">
				<div class="col-sm-2 ">
					<div class="form-group">
						<label for="loteOrigem">Código:</label> 
						<input type="text" class="form-control" name="codamostra" id="codamostra" value="<?php echo $idamostra?>" disabled="true">
					</div>
				</div>
				<div class="col-sm-2 ">
					<div class="form-group">
						<label for="loteOrigem">Lote de Origem:</label> 
						<input type="text" class="form-control" name="loteOrigem" id="loteOrigem" value="<?php echo $idlote?>" disabled="true">
					</div>
				</div>
				<div class="form-group col-sm-4 ">
					<label for="categoria">Categoria:</label> <!-- fornecido ou colhido -->
					<input type="text" class="form-control" name="categoria" id="categoria" value="<?php echo $categoria?>" disabled="">
				</div>	
				<div class="form-group col-sm-4 ">
					<label for="dataEntradaLoteOrigem">Data de entrada:</label> 
					<input type="text" class="form-control" name="dataEntradaLoteOrigem" id="dataEntradaLoteOrigem" value="<?php echo $dtchegada?>" disabled="true">
				</div>

			</div>

			<div class="row">
				<div class="form-group col-sm-4">
					<label  for="especie">Especie:</label>
					<input type="text"  class="form-control"  name="especie" id="especie"  value="<?php echo $nomevulgar?>" disabled="true">
				</div>
				<div class="form-group col-sm-4">
					<label for="condicaoArmazenamento">Condição de Armazenamento:</label>	
					<input type="text"  class="form-control"  name="condicaoArmazenamento"value="<?php echo $armazenamento?>" id="condicaoArmazenamento"  disabled="true">
				</div>
				<div class="form-group col-sm-4">
					<label  for="dataImplatacao">Data Implantação:</label>
					<input type="date"  class="form-control"  name="dataImplatacao" id="dataImplatacao" value="<?php echo $dtimplantacao?>"  disabled="true">
				</div>
			</div>	

			<h3>Análises</h3>
			<hr>	
			<h4>Teor de Água</h4>
			<div class="container-fluid">
				<table  class="table table-hover">
					<thead>
						<tr>
							<th scope="col">N° do Cadinho</th>
							<th scope="col">Peso do Cadinho</th>
							<th scope="col">Peso Úmido</th>
							<th scope="col">Peso Seco</th>
							<th scope="col">Úmidade (%)</th>
							<th scope="col">Úmidade Média (%)</th>
							<th scope="col">Opções</th>
						</tr>
					</thead>
					<tbody>
						<?php 
						if ($tbteoragua->numRows() > 0) {
							foreach ($tbteoragua->result() as $tbteoragua ){ ?>
								<tr>
									<td ><?php echo $tbteoragua['num_cadinho']; ?></td>
									<td ><?php echo $tbteoragua['peso_cadinho']; ?></td>
									<td ><?php echo $tbteoragua['peso_umido']; ?></td>
									<td ><?php echo $tbteoragua['peso_seco']; ?></td>
									<td ><?php echo $tbteoragua['umidade']; ?></td>
									<td ><?php echo $tbteoragua['umidade_media']; ?></td>
									<td>
										<button type="button" id="<?php echo $tbteoragua['idteste_teor_agua'];?>" class="btn btn-info">Ver</button> 
										<button type="button" id="<?php echo $tbteoragua['idteste_teor_agua'];?>" class="btn btn-danger">Excluir</button>
									</td>
								</tr>										
							<?php }
						}
						?> 
					</tbody>
				</table>
			</div>

			<hr>
			<h4>Num. Sementes</h4>
			<div class="container-fluid">
				<table  class="table table-hover">
					<thead>
						<tr>
							<th scope="col">N° de Sementes</th>
							<th scope="col">Peso da Amostra</th>
							<th scope="col">N° Sementes (KH)</th>
							<th scope="col">Opções<th>
							</tr>
						</thead>
						<tbody>
							<?php 
							if ($tbnumerosementes->numRows() > 0) {
								foreach ($tbnumerosementes->result() as $tbnumerosemente ){ ?>
									<tr>
										<td><?php echo $tbnumerosemente['qtd_num_sementes']; ?></td>
										<td><?php echo $tbnumerosemente['peso_amostra']; ?></td>
										<td><?php echo $tbnumerosemente['kh_num_sementes']; ?></td>
										<td>
											<button type="button" id="<?php echo $tbnumerosemente['idteste_num_sementes'];?>" class="btn btn-info">Ver</button> 
											<button type="button" id="<?php echo $tbnumerosemente['idteste_num_sementes'];?>" class="btn btn-danger">Excluir</button>
										</td>
									</tr>
								<?php }
							}
							?> 
						</tbody>
					</table>
				</div>

				<hr>
				<h4>Teste Germinação</h4>
				<div class="container-fluid">
					<table  class="table table-hover">
						<thead>
							<tr>
								<th scope="col">N° dia da semeadura</th>
								<th scope="col">Data</th>
								<th scope="col">R1</th>
								<th scope="col">R2</th>
								<th scope="col">R3</th>
								<th scope="col">R4</th>
								<th scope="col">R5</th>
								<th scope="col">R6</th>
								<th scope="col">R7</th>
								<th scope="col">R8</th>
								<th scope="col">Total</th>
								<th scope="col">Opções</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>teste</td>
								<td>teste</td>
								<td>teste</td>
								<td>teste</td>
								<td>teste</td>
								<td>teste</td>
								<td>teste</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
			<!-- ------------------------- Cadstro Numero de Sementes ------------------------------- -->
			<div id="menu1" class="tab-pane fade">
				<h3>Número de Sementes</h3>

				<form  name="formCardastroNumSementes" id="formCardastroNumSementes" method="POST" action="crud-amostra.php">
					<div class="row">
						<div class="col-sm-2 ">
							<div class="form-group">
								<label for="loteOrigem">Código:</label> 
								<input type="text" class="form-control" name="codamostra" id="codamostra" value="<?php echo $idamostra?>" readonly="">
							</div>
						</div>
						<div class="col-sm-2 ">
							<div class="form-group">
								<label for="loteOrigem">Lote de Origem:</label> 
								<input type="text" class="form-control" name="loteOrigem" id="loteOrigem" value="<?php echo $idlote?>" disabled="" >
							</div>
						</div>
						<div class="form-group col-sm-2 ">
							<label  for="especie">Especie:</label>
							<input type="text"  class="form-control"  name="especie" id="especie"  value="<?php echo $nomevulgar?>" disabled="">
						</div>	
						<div class="form-group col-sm-2 ">
							<label for="datanumsementes">Data Análise:</label> 
							<input type="date" class="form-control" name="datanumsementes" id="datanumsementes" required="">
						</div>
						<div class="form-group col-sm-4 ">
							<label for="analistaTesteNumSementes"> Analista: </label>
							<input type="text" class="form-control" name="analistaTesteNumSementes" id="analistaTesteNumSementes" maxlength="30" minlength="4" placeholder="Ex.: João da Silva" required="">
						</div>

					</div>
					<div class="row">
						<div class="col-sm-4 ">
							<div class="form-group">
								<label for="numSementes"> N° de Sementes: </label>
								<input type="number" class="form-control" name="numSementes" id="numSementes" min="0"  placeholder="Ex.: 500" required="">
							</div>
						</div>
						<div class="col-sm-4 ">
							<div class="form-group">
								<label for="pesoAmostra"> Peso da Amostra: </label>
								<input type="number" step="0.01" class="form-control" name="pesoAmostra" id="pesoAmostra" min="0"  placeholder="Ex.: 10" required="">
							</div>
						</div>
						<div class="form-group col-sm-4 ">
							<label for="numSementesKh"> N° Sementes (KH): </label>
							<input type="number" step="0.01" class="form-control" name="numSementesKh" id="numSementesKh"  min="0"  placeholder="Ex.: 10" required="">
						</div>
					</div>	
					<div class="row">
						<div class="form-group col-sm-12">
							<label for="obsTesteUmidade">Observação</label>
							<textarea  class="form-control" rows="5" name="obsTesteUmidade" id="obsTesteUmidade"></textarea>
						</div>
					</div>	
					<div class="row">
						<div class="form-group col-sm-12">
							<button class="btn btn-success btn-md" name="acao" value="createNumSementes"><span class="fa fa-plus-square-o"></span> Salvar </button>
						</div>
					</div>
				</form>
			</div>
			<!------------------------- Cadastro Teor de Agua -------------------------------->
			<div id="menu2" class="tab-pane fade">
				<h3>Análise Teor de Água</h3>
				<form name="formTesteTeorAgua" id="formTesteTeorAgua" method="POST" action="crud-amostra.php">
					<div class="row">
						<div class="col-sm-2 ">
							<div class="form-group">
								<label for="loteOrigem">Código:</label> 
								<input type="text" class="form-control" name="codamostra" id="codamostra" value="<?php echo $idamostra?>" readonly="">
							</div>
						</div>
						<div class="col-sm-2 ">
							<div class="form-group">
								<label for="loteOrigem">Lote de Origem:</label> 
								<input type="text" class="form-control" name="loteOrigem" id="loteOrigem" value="<?php echo $idlote?>" disabled="" >
							</div>
						</div>
						<div class="form-group col-sm-2 ">
							<label  for="especie">Especie:</label>
							<input type="text"  class="form-control"  name="especie" id="especie"  value="<?php echo $nomevulgar?>" disabled="">
						</div>
						<div class="form-group col-sm-2">
							<label for="dataTesteTeorAgua">Data Análise:</label> 
							<input type="date" class="form-control" name="dataTesteTeorAgua" id="dataTesteTeorAgua" required="">
						</div>
						<div class="form-group col-sm-4">
							<label for="analistaTesteTeorAgua">Analista:</label>
							<input type="text" class="form-control" name="analistaTesteTeorAgua" id="analistaTesteTeorAgua"    maxlength="30" minlength="4" placeholder="Ex.: João da Silva" required="">  
						</div>	
					</div>

					<div class="row">
						<div class="form-group col-sm-4">
							<label for="numCadinho">N° Cadinho:</label>
							<input type="number" class="form-control" name="numCadinho" id="numCadinho"   min="0" placeholder="Ex.: 1" required="">
						</div>

						<div class="form-group col-sm-4">
							<label for="pesoCadinho">Peso do Cadinho:</label>
							<input type="number" step="0.01" class="form-control" name="pesoCadinho" id="pesoCadinho" min="0" placeholder="Ex.: 1,25" required=""> 
						</div>

						<div class="form-group col-sm-4">
							<label for="pesoUmido">Peso Úmido:</label> 
							<input type="number" step="0.01" class="form-control" name="pesoUmido" id="pesoUmido" min="0" placeholder="Ex.: 3,45" required="">
						</div>
					</div>

					<div class="row">
						<div class="form-group col-sm-4">
							<label for="pesoSeco">Peso Seco:</label>      
							<input type="number" step="0.01" class="form-control" name="pesoSeco" id="pesoSeco" min="0" placeholder="Ex.: 1" required="">
						</div>

						<div class="form-group col-sm-4">
							<label for="umidade">Umidade (%):</label>
							<input type="number" step="0.01" class="form-control" name="umidade" id="umidade" min="0"  placeholder="Ex.: 30" required="">
						</div>

						<div class="form-group col-sm-4">
							<label for="umidadeMedia">Umidade Média (%):</label>
							<input type="number" step="0.01" class="form-control" name="umidadeMedia" id="umidadeMedia" min="1" placeholder="Ex.: 30" required="">
						</div>
					</div>

					<div class="row">  
						<div class="form-group col-sm-12">
							<label for="obsTesteUmidade">Observação</label>
							<textarea  class="form-control" rows="5" name="obsTesteUmidade"  maxlength="255" minlength="1"  id="obsTesteUmidade"></textarea>
						</div>
					</div>

					<div class="row">          
						<div class="form-group col-sm-12">
							<button class="btn btn-success btn-md" name="acao" value="createTesteTeorAgua"><span class="fa fa-plus-square-o"></span> Salvar </button>
						</div>
					</div>
				</form>
			</div>
			
			<div id="menu3" class="tab-pane fade">
				<h3>Análise da Germinação</h3>
				<form name="formCardastroTesteGerminacao" id="formCardastroTesteGerminacao" method="get" action="#">	
					<div class="row">
						<div class="form-group col-sm-6">
							<label for="analistaTesteGerminacao">Analista:</label>
							<input type="text" class="form-control" name="analistaTesteGerminacao" id="analistaTesteGerminacao" required="">  
						</div>

						<div class="form-group col-sm-2">
							<label for="dataSemeadura">Data Semeadura:</label> 
							<input type="date" class="form-control" name="dataSemeadura" id="dataSemeadura" required="">
						</div>
					</div>

					<div class="row">
						<div class="form-group col-sm-4">
							<label for="temperatura">Temperatura ():</label>
							<input type="number" class="form-control" name="temperatura" id="temperatura" required="">
						</div>

						<div class="form-group col-sm-4">
							<label for="subtrato">Substrato:</label> <!--Talvez esse campo seja adicionado-->
							<input type="text" class="form-control" name="subtrato" id="subtrato" required="">
						</div>
					</div>


					<div class="row">
						<div class="form-group col-sm-4">
							<label for="numRepeticao">N° Sementes/Repetição:</label>
							<input type="number" class="form-control" name="numRepeticao"  id="numRepeticao" required="">
						</div>

						<div class="form-group col-sm-4">
							<label for="tratamento">Tratamento:</label>
							<input type="text" class="form-control" name="tratamento" id="tratamento" required="">
						</div>
					</div>
				</form>
				<p>Eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
			</div>
		</div>
	</div>



	<?php
	require_once 'footer.php';

	?>





