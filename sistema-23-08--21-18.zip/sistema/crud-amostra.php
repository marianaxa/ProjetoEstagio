<?php

require 'crud.php';
$amostra = new Crud();
$testenumerosementes = new Crud();
$testegerminacao = new Crud();
$totalplantulas = new Crud();
$plantulasanormais = new Crud();
$sementesfirmes = new Crud();
$sementesmortas = new Crud();
$sementeschocas = new Crud();


$acaoCol = $_POST['acao'];

switch ($acaoCol) {
	case "create":

	//enviar id do lote pelo btn cadastrar
	//receber o id do lote
	//fazer insert na amostra peganndo os dados: armazenamento e implantacao
	$loteFK = $_POST['idlote'];
	$condicaoArmazenamento = $_POST['condicaoArmazenamento'];
	$dataImplantacao =$_POST['dataImplatacao'];
	$amostrador = $_POST['amostrador'];

	$amostra->insert("amostra",
		array("condicao_armazenamento" => $condicaoArmazenamento,
			"data_implantacao"  => $dataImplantacao,	
			"loteFK" => $loteFK,
			"amostrador" => $amostrador,
			"situacao" => 'iniciada'
		)
	);
	header('Location: lista-amostra.php');

	break;

	case "createNumSementes":

	$idamostra = $_POST['codamostra'];
	$dataNumSementes =$_POST['datanumsementes'];
	$analistaTesteNumSementes = $_POST['analistaTesteNumSementes'];
	$qtdNumSementes = $_POST['numSementes'];
	$pesoAmostra = $_POST['pesoAmostra'];
	$khNumSementes = $_POST['numSementesKh'];
	$obsTesteUmidade = $_POST['obsTesteUmidade'];


	$testenumerosementes->insert("teste_num_sementes",
		array("data_num_sementes" => $dataNumSementes,
			"analista_num_sementes"  => $analistaTesteNumSementes,	
			"qtd_num_sementes" => $qtdNumSementes,	
			"peso_amostra" => $pesoAmostra,	
			"kh_num_sementes" => $khNumSementes,
			"observacoes_num_sementes" => $obsTesteUmidade,
			"amostraFK" => $idamostra		  

		)
	);
	header("Location: informacao-amostra.php?idamostra=".$idamostra);

	break;

	case "createTesteTeorAgua":

	$idamostra = $_POST['codamostra'];
	$dataTesteTeorAgua =$_POST['dataTesteTeorAgua'];
	$analistaTesteTeorAgua = $_POST['analistaTesteTeorAgua'];
	$numCadinho = $_POST['numCadinho'];
	$pesoCadinho = $_POST['pesoCadinho'];
	$pesoUmido = $_POST['pesoUmido'];
	$pesoSeco = $_POST['pesoSeco'];
	$umidade = $_POST['umidade'];
	$umidadeMedia = $_POST['umidadeMedia'];
	$obsTesteUmidade = $_POST['obsTesteUmidade'];


	$testenumerosementes->insert("teste_teor_agua",
		array("data_teor_agua" => $dataTesteTeorAgua,
			"analista_teor_agua"  => $analistaTesteTeorAgua,	
			"num_cadinho" => $numCadinho,	
			"peso_cadinho" => $pesoCadinho,	
			"peso_umido" => $pesoUmido,	
			"peso_seco" => $pesoSeco,
			"umidade" => $umidade,
			"umidade_media" => $umidadeMedia,
			"obs_teor_agua" => $obsTesteUmidade,
			"amostraFK" => $idamostra
		)
	);
	header("Location: informacao-amostra.php?idamostra=".$idamostra);

	break;

	case "createTesteGerminacao":

	$idamostra = $_POST['codamostra'];
	$dataSemeadura =$_POST['dataSemeadura'];
	$analistaTesteGerminacao = $_POST['analistaTesteGerminacao'];
	$temperatura = $_POST['temperatura'];
	$substrato = $_POST['substrato'];
	$tratamento = $_POST['tratamento'];
	$numDiasSemeadura = $_POST['numDiasSemeadura'];
	$dataLinhaSemeadura = $_POST['dataLinhaSemeadura'];
	$repeticao1 = $_POST['repeticao1'];
	$repeticao2 = $_POST['repeticao2'];
	$repeticao3 = $_POST['repeticao3'];
	$repeticao4 = $_POST['repeticao4'];
	$totalRepeticao = $_POST['totalrepeticao'];


	$testegerminacao->insert("teste_germinacao",
		array("data_semeadura" => $dataSemeadura,
			"analista_teste_germinacao"  => $analistaTesteGerminacao,	
			"temperatura" => $temperatura,
			"substrato" => $substrato,		
			"tratamento" => $tratamento,
			"num_dias_semeadura" => $numDiasSemeadura,
			"data" => $dataLinhaSemeadura,
			"repeticao1" => $repeticao1,
			"repeticao2" => $repeticao2,
			"repeticao3" => $repeticao3,
			"repeticao4" => $repeticao4,
			"total_repeticao" => $totalRepeticao,			
			"amostraFK" => $idamostra
		)
	);

//	echo "fim cadastro ..";
	header("Location: informacao-amostra.php?idamostra=".$idamostra);

	break;
	case "createResultado":

	$idamostra = $_POST['codamostra'];
	//total plantulas
	$dataTotalPlantulas =$_POST['dataTotalPlantulas'];
	$totalplantulasrepeticao1 = $_POST['totalplantulasrepeticao1'];
	$totalplantulasrepeticao2 = $_POST['totalplantulasrepeticao2'];
	$totalplantulasrepeticao3 = $_POST['totalplantulasrepeticao3'];
	$totalplantulasrepeticao4 = $_POST['totalplantulasrepeticao4'];
	$totalplantulasrepeticao = $_POST['totalplantulasrepeticao'];
	//plantulas anormais
	$dataPlantulasAnormais = $_POST['dataPlantulasAnormais'];
	$plantulasanormaisrepeticao1 = $_POST['plantulasanormaisrepeticao1'];
	$plantulasanormaisrepeticao2 = $_POST['plantulasanormaisrepeticao2'];
	$plantulasanormaisrepeticao3 = $_POST['plantulasanormaisrepeticao3'];
	$plantulasanormaisrepeticao4 = $_POST['plantulasanormaisrepeticao4'];
	$plantulasanormaisrepeticao = $_POST['plantulasanormaisrepeticao'];
	//sementes firmes
	$dataSementesFirmes = $_POST['dataSementesFirmes'];
	$sementesfirmesrepeticao1 = $_POST['sementesfirmesrepeticao1'];
	$sementesfirmesrepeticao2 = $_POST['sementesfirmesrepeticao2'];
	$sementesfirmesrepeticao3 = $_POST['sementesfirmesrepeticao3'];
	$sementesfirmesrepeticao4 = $_POST['sementesfirmesrepeticao4'];
	$sementesfirmesrepeticao = $_POST['sementesfirmesrepeticao'];
	//sementes mortas
	$dataSementesMortas = $_POST['dataSementesMortas'];
	$sementesmortasrepeticao1 = $_POST['sementesmortasrepeticao1'];
	$sementesmortasrepeticao2 = $_POST['sementesmortasrepeticao2'];
	$sementesmortasrepeticao3 = $_POST['sementesmortasrepeticao3'];
	$sementesmortasrepeticao4 = $_POST['sementesmortasrepeticao4'];
	$sementesmortasrepeticao = $_POST['sementesmortasrepeticao'];
	//sementes chocas
	$dataSementesChocas = $_POST['dataSementesChocas'];
	$sementeschocasrepeticao1 = $_POST['sementeschocasrepeticao1'];
	$sementeschocasrepeticao2 = $_POST['sementeschocasrepeticao2'];
	$sementeschocasrepeticao3 = $_POST['sementeschocasrepeticao3'];
	$sementeschocasrepeticao4 = $_POST['sementeschocasrepeticao4'];
	$sementeschocasrepeticao = $_POST['sementeschocasrepeticao'];


	$totalplantulas->insert("total_plantulas4",
		array("data" => $dataTotalPlantulas,
			"r1"  => $totalplantulasrepeticao1,	
			"r2" => $totalplantulasrepeticao2,
			"r3" => $totalplantulasrepeticao3,		
			"r4" => $totalplantulasrepeticao4,
			"total" => $totalplantulasrepeticao,
			"amostraFK" => $idamostra
		)
	);

	$plantulasanormais->insert("plantulas_anormais4",
		array("data" => $dataPlantulasAnormais,
			"r1"  => $plantulasanormaisrepeticao1,	
			"r2" => $plantulasanormaisrepeticao2,
			"r3" => $plantulasanormaisrepeticao3,		
			"r4" => $plantulasanormaisrepeticao4,
			"total" => $plantulasanormaisrepeticao,
			"amostraFK" => $idamostra
		)
	);

	$sementesfirmes->insert("sementes_firmes4",
		array("data" => $dataSementesFirmes,
			"r1"  => $sementesfirmesrepeticao1,	
			"r2" => $sementesfirmesrepeticao2,
			"r3" => $sementesfirmesrepeticao3,		
			"r4" => $sementesfirmesrepeticao4,
			"total" => $sementesfirmesrepeticao,
			"amostraFK" => $idamostra
		)
	);

	$sementesmortas->insert("sementes_mortas4",
		array("data" => $dataSementesMortas,
			"r1"  => $sementesmortasrepeticao1,	
			"r2" => $sementesmortasrepeticao2,
			"r3" => $sementesmortasrepeticao3,		
			"r4" => $sementesmortasrepeticao4,
			"total" => $sementesmortasrepeticao,
			"amostraFK" => $idamostra
		)
	);

	$sementeschocas->insert("sementes_chocas4",
		array("data" => $dataSementesChocas,
			"r1"  => $sementeschocasrepeticao1,	
			"r2" => $sementeschocasrepeticao2,
			"r3" => $sementeschocasrepeticao3,		
			"r4" => $sementeschocasrepeticao4,
			"total" => $sementeschocasrepeticao,
			"amostraFK" => $idamostra
		)
	);
//	echo "fim cadastro ..";
	header("Location: informacao-amostra.php?idamostra=".$idamostra);

	break;


	default:
	echo "Ação não encontrada";
}

?>